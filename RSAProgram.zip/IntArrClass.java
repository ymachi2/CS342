import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.filechooser.*;

public class IntArrClass{
    private int[] numArray;
    private int size;
    private boolean negative;
    
    public IntArrClass(long x){
      int numSize = 0 ;
      long number = x;
      if(x < 0){
        this.size = 0;
        this.numArray = new int[1];
      }
      
      while(x > 0){
        x = x/10;
        ++numSize;
      }
      
      this.numArray = new int[numSize];
      this.size = numSize;
      
      for(int i = 0; i < numSize; ++i){
        numArray[i] = (int) (number % 10);
        number = number/10;
      }
    }
    
    public void printNumber(){
      if(this.size == 0){
        System.out.print(0);
        System.out.println();
        return;
      }
      for(int i = this.size-1; i >= 0; --i){
        System.out.print(numArray[i]);
      }
      System.out.println();
    }
    
    public int getSize(){
      return this.size;
    }
    
    public void grow(){
      int[] newArray = new int[numArray.length*2];
      System.arraycopy(numArray, 0, newArray, 0, size);
      numArray = newArray;
    }
    
    public boolean isGreaterThan(IntArrClass y){
      if(this.size > y.getSize()){
        return true;
      }
      else if(this.size == y.getSize()){
        for(int i = this.getSize() - 1; i >= 0; --i){
          if(this.numArray[i] > y.numArray[i]){
            return true;
          }
          else if(this.numArray[i] < y.numArray[i]){
            return false;
          }
        }
      }
      
      return false;
    }
    
    public boolean isLessThan(IntArrClass y){
      if(this.size < y.getSize()){
        return true;
      }
      else if(this.size == y.getSize()){
        for(int i = this.getSize() - 1; i >= 0; --i){
          if(this.numArray[i] < y.numArray[i]){
            return true;
          }
          else if(this.numArray[i] > y.numArray[i]){
            return false;
          }
        }
      }
      
      return false;
    }
    
    public boolean isEqualTo(IntArrClass y){
      if(this.size != y.getSize()){
        return false;
      }
      else if(this.size == y.getSize()){
        for(int i = this.getSize() - 1; i >= 0; --i){
          if(this.numArray[i] != y.numArray[i]){
            return false;
          }
        }
      }
      
      return true;
    }
    
    public void add(IntArrClass y){
      
      while(y.getSize() >= this.numArray.length){
        this.grow();
      }
      
      int i = 0;
      
      for(i = 0; i < this.getSize(); ++i){
        if(i >= y.getSize()){
          if(this.numArray[i] >= 10){
            if((i+1) >= this.getSize()){
              ++this.size;
              this.numArray[i+1] += this.numArray[i]/10;
              this.numArray[i] = this.numArray[i]%10;
            }
          }
        }
        else{
          this.numArray[i] += y.numArray[i];
          
          if(this.numArray[i] >= 10){
            if((i+1) >= this.getSize()){
              ++this.size;
            }
            this.numArray[i+1] += this.numArray[i]/10;
            this.numArray[i] = this.numArray[i]%10;
          }
        }
      }
      
      if(y.getSize() > i){
        
        for(int j = this.getSize(); j < y.getSize(); ++j){
          this.numArray[j] = y.numArray[j];
          ++this.size;
        }
        
      }
      
    }
    
    public void subtract(IntArrClass y){
      
      if(this.isGreaterThan(y)){
        int i = 0;
      
        for(i = 0; i < this.getSize(); ++i){
          
          if(i >= y.getSize()){
            y.grow();
          }
          
          if(this.numArray[i] < y.numArray[i]){
            --this.numArray[i+1];
            this.numArray[i] = (10+this.numArray[i]) - y.numArray[i];
          }
          else{
            this.numArray[i] = this.numArray[i] - y.numArray[i];
          }
        }
      
      }
      else{
        if(this.isLessThan(y)){
          int[] zeroArr = new int[this.getSize()];
          this.size = 0;
          this.numArray = zeroArr;
        }
        
        return;
      }
      
      
      int newSize = 0;
      for(int j = this.getSize()-1; j >= 0; --j){
        if(newSize >= 1 && this.numArray[j] == 0){
          ++newSize;
        }
        if(this.numArray[j] != 0){
          ++newSize;
        }
      }
      
      this.size = newSize;
      
    }  
  }