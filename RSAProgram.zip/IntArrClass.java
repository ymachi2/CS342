import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.filechooser.*;

public class IntArrClass{
    private int[] numArray;
    private int size;
    
    public IntArrClass(long x){
      int numSize = 0 ;
      long number = x;
      if(x < 0){
        this.size = 0;
        this.numArray = new int[1];
      }
      
      while(x > 0){
        x = x/10;
        ++numSize;
      }
      
      this.numArray = new int[numSize];
      this.size = numSize;
      
      for(int i = 0; i < numSize; ++i){
        numArray[i] = (int) (number % 10);
        number = number/10;
      }
    }
    
    public void printNumber(){
      if(this.size == 0){
        System.out.print(0);
        System.out.println();
        return;
      }
      for(int i = this.size-1; i >= 0; --i){
        System.out.print(numArray[i]);
      }
      System.out.println();
    }
    
    public int getSize(){
      return this.size;
    }
    
    public void grow(){
      int[] newArray = new int[numArray.length*2];
      System.arraycopy(numArray, 0, newArray, 0, size);
      numArray = newArray;
    }
    
    public boolean isGreaterThan(IntArrClass y){
      if(this.size > y.getSize()){
        return true;
      }
      else if(this.size == y.getSize()){
        for(int i = this.getSize() - 1; i >= 0; --i){
          if(this.numArray[i] > y.numArray[i]){
            return true;
          }
          else if(this.numArray[i] < y.numArray[i]){
            return false;
          }
        }
      }
      
      return false;
    }
    
    public boolean isLessThan(IntArrClass y){
      if(this.size < y.getSize()){
        return true;
      }
      else if(this.size == y.getSize()){
        for(int i = this.getSize() - 1; i >= 0; --i){
          if(this.numArray[i] < y.numArray[i]){
            return true;
          }
          else if(this.numArray[i] > y.numArray[i]){
            return false;
          }
        }
      }
      
      return false;
    }
    
    public boolean isEqualTo(IntArrClass y){
      if(this.size != y.getSize()){
        return false;
      }
      else if(this.size == y.getSize()){
        for(int i = this.getSize() - 1; i >= 0; --i){
          if(this.numArray[i] != y.numArray[i]){
            return false;
          }
        }
      }
      
      return true;
    }
    
    public void add(IntArrClass y){
      
      while(y.getSize() >= this.numArray.length){
        this.grow();
      }
      
      int i = 0;
      
      for(i = 0; i < this.getSize(); ++i){
        if(i >= y.getSize()){
          if(this.numArray[i] >= 10){
            if((i+1) >= this.getSize()){
              ++this.size;
              this.numArray[i+1] += this.numArray[i]/10;
              this.numArray[i] = this.numArray[i]%10;
            }
          }
        }
        else{
          this.numArray[i] += y.numArray[i];
          
          if(this.numArray[i] >= 10){
            if((i+1) >= this.getSize()){
              ++this.size;
            }
            this.numArray[i+1] += this.numArray[i]/10;
            this.numArray[i] = this.numArray[i]%10;
          }
        }
      }
      
      if(y.getSize() > i){
        
        for(int j = this.getSize(); j < y.getSize(); ++j){
          this.numArray[j] = y.numArray[j];
          ++this.size;
        }
        
      }
      
    }
    
    public void subtract(IntArrClass y){
      
      if(this.isGreaterThan(y)){
        int i = 0;
      
        for(i = 0; i < this.getSize(); ++i){
          
          if(i >= y.getSize()){
            y.grow();
          }
          
          if(this.numArray[i] < y.numArray[i]){
            --this.numArray[i+1];
            this.numArray[i] = (10+this.numArray[i]) - y.numArray[i];
          }
          else{
            this.numArray[i] = this.numArray[i] - y.numArray[i];
          }
        }
      
      }
      else{
        if(this.isLessThan(y)){
          int[] zeroArr = new int[this.getSize()];
          this.size = 0;
          this.numArray = zeroArr;
        }
        
        return;
      }
      
      
      int newSize = 0;
      for(int j = this.getSize()-1; j >= 0; --j){
        if(newSize >= 1 && this.numArray[j] == 0){
          ++newSize;
        }
        if(this.numArray[j] != 0){
          ++newSize;
        }
      }
      
      this.size = newSize;
      
    }
    
    public void multiply(IntArrClass y){
      
      IntArrClass[] subresults;
      
      if(this.isGreaterThan(y) || this.isEqualTo(y)){
        
        subresults = new IntArrClass[this.getSize()];
        
        for(int i = 0; i < subresults.length; ++i){
          
          subresults[i] = new IntArrClass(0);
          subresults[i].numArray = new int[this.getSize()*3];
          subresults[i].size = 0;
          
        }
      
        for(int i = 0; i < this.getSize(); ++i){
        
          for(int j = 0; j < y.getSize(); ++j){
          
            subresults[i].numArray[j] += this.numArray[i] * y.numArray[j];
            ++subresults[i].size;
            
            if(subresults[i].numArray[j] >= 10){
              subresults[i].numArray[j+1] += subresults[i].numArray[j]/10;
              subresults[i].numArray[j] = subresults[i].numArray[j]%10;
              ++subresults[i].size;
            }
               
          }
          
        }
        
        
        if(subresults.length > 1){
          
          for(int i = 1; i < subresults.length; ++i){
            
            for(int j = subresults.length + i; j >= i; --j){
             
              subresults[i].numArray[j] = subresults[i].numArray[j-i];
              subresults[i].numArray[j-i] = 0;
              
            }
            
            subresults[i].size += i;
            int newSize = 0;
            for(int k = subresults[i].size -1; k >= 0; --k){
              if(newSize >= 1 && subresults[i].numArray[k] == 0){
                ++newSize;
              }
              if(subresults[i].numArray[k] != 0){
                ++newSize;
              }
            }
      
            subresults[i].size = newSize;
            
          }
        }
        
        for(int i = 0; i < subresults.length - 1; ++i){
          
          subresults[0].add(subresults[i+1]);
          
        }
        
        this.numArray = subresults[0].numArray;
        this.size = subresults[0].size;
        
      }
      else{
        
        IntArrClass temp = y;
        temp.multiply(this);
        this.numArray = temp.numArray;
        this.size = temp.size;
          
      }
        
    }
   
      
      
}
