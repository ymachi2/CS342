import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.filechooser.*;

public class RSAProgram extends JFrame{
  private JButton createKey, blockFile, unBlock, encrypt, decrypt, chooseFile;
  private JLabel fileNameLabel;
  String fileName;
  File currFile;
  
  public static void main(String[] args){
   
    RSAProgram frame = new RSAProgram();
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    
    System.out.println("Let's get started...");
    
    IntArrClass number = new IntArrClass(9231993);
    IntArrClass number2 = new IntArrClass(9231993);
    IntArrClass number3 = new IntArrClass(4110441);
    IntArrClass number4 = new IntArrClass(9222993);
    number.printNumber();
    
    number.subtract(number4);
    number.printNumber();
    System.out.println("Number has a size of " + number.getSize());
    
    /*number.add(number2);
    number.printNumber();
    
    number.subtract(number2);
    number.printNumber();
    number.subtract(number3);
    number.printNumber();
    number.subtract(number3);
    number.printNumber();
    if(number3.isGreaterThan(number)){
      System.out.println("number3 is greater than number");
    }
    number.subtract(number3);
    number.printNumber();
    
    System.out.println("Number has a size of " + number.getSize());
    System.out.println("Number2 has a size of " + number2.getSize());
    System.out.println("Number3 has a size of " + number3.getSize());
    */
    /*if(number2.isGreaterThan(number)){
      System.out.println("number2 is greater than number");
    }
    if(number2.isLessThan(number)){
      System.out.println("number2 is less than number");
    }
    if(number.isEqualTo(number2)){
      System.out.println("number2 is equal to number");
    }
    
    number.add(number2);
    number.printNumber();
    
    if(number.isGreaterThan(number2)){
      System.out.println("number is greater than number2");
    }
    if(number2.isLessThan(number)){
      System.out.println("number2 is less than number");
    }
    if(number.isEqualTo(number2)){
      System.out.println("number2 is equal to number");
    }
    
    
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number2.printNumber();
    number2.add(number);
    number2.printNumber();
    
    System.out.println("Number has a size of " + number.getSize());
    System.out.println("Number2 has a size of " + number2.getSize());
    */
  }
  
  public RSAProgram()
  {
    
    super("RSA Program");
    
    ButtonHandler buttonHandler = new ButtonHandler();
    
    Container container = getContentPane();
    JPanel panel1 = new JPanel();
    panel1.setLayout(new BorderLayout());
    JPanel panel2 = new JPanel();
    JPanel panel3 = new JPanel();
    panel3.setLayout(new BorderLayout());
    JPanel panel4 = new JPanel();
    panel4.setLayout(new FlowLayout());
    
    
    createKey = new JButton("Create RSA keys");
    panel1.add(createKey);
    container.add(panel1,BorderLayout.WEST);
    
    
    blockFile = new JButton("Block File");
    panel2.add(blockFile);
    unBlock = new JButton("Unblock File");
    panel2.add(unBlock);
    panel1.add(panel2,BorderLayout.SOUTH);
    
    encrypt = new JButton("Encrypt");
    decrypt = new JButton("Decrypt");
    panel3.add(encrypt,BorderLayout.WEST);
    panel3.add(decrypt,BorderLayout.EAST);
    container.add(panel3,BorderLayout.EAST);
    
    fileNameLabel = new JLabel("No file chosen.");
    panel4.add(fileNameLabel);
    chooseFile = new JButton("Choose File");
    chooseFile.addActionListener(buttonHandler);
    panel4.add(chooseFile);
    container.add(panel4,BorderLayout.NORTH);
    
    
    
    setSize(500, 250);
    setVisible(true);
      
  }
  
  public class ButtonHandler implements ActionListener{
    public void actionPerformed(ActionEvent e) {
      if (e.getSource() == chooseFile){
        JFileChooser chooser = new JFileChooser(".\\");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files (*.txt, *.text)", "txt", "text");
        chooser.setFileFilter(filter);
        int success = chooser.showOpenDialog(null);
        
        if(success == JFileChooser.APPROVE_OPTION){
          if(chooser.getSelectedFile().getName().contains(".txt")){
            fileName = chooser.getSelectedFile().getName();
            currFile = chooser.getSelectedFile();
            fileNameLabel.setText(fileName);
          }
          else{
            JOptionPane.showMessageDialog(null, "Could not open file...");
          }
        }
      }
      else{
        JOptionPane.showMessageDialog(null, "Could not open file...");
      }
    }
  }
}

  