import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.filechooser.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Random;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;



public class RSAProgram extends JFrame{
  private JButton createKey, blockFile, unBlock, encrypt, decrypt, chooseFile;
  private JLabel fileNameLabel;
  private JLabel lastAction;
  private String fileName;
  private File currFile;
  private boolean fileChosen;
  
  public static void main(String[] args){
   
    RSAProgram frame = new RSAProgram();
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    
    System.out.println("Let's get started...");
    
    IntArrClass number = new IntArrClass(999999998);
    IntArrClass number2 = new IntArrClass(9231993);
    IntArrClass number3 = new IntArrClass(4110441);
    IntArrClass number4 = new IntArrClass(9222993);
    IntArrClass number5 = new IntArrClass(4110441);
    IntArrClass number6 = new IntArrClass(8220882);
    IntArrClass number7 = new IntArrClass(8220882);
    number.printNumber();
    
    number2.multiply(new IntArrClass(2));
    
    IntArrClass number23 = new IntArrClass(23);
    IntArrClass numberNew2 = new IntArrClass(2);
    IntArrClass numberNew3 = new IntArrClass(3);
    
    number.mod(numberNew3).printNumber();
    number.divide(numberNew3);
    number.printNumber();
    
    number23.mod(numberNew2).printNumber();
    number23.divide(numberNew2);
    number23.printNumber();
    
    number2.divide(number3);
    number2.printNumber();
    
    /*number.multiply(new IntArrClass(999999999));
    number.printNumber();
    System.out.println("Number has a size of " + number.getSize());
    */
    
    /*number.add(number2);
    number.printNumber();
    
    number.subtract(number2);
    number.printNumber();
    number.subtract(number3);
    number.printNumber();
    number.subtract(number3);
    number.printNumber();
    if(number3.isGreaterThan(number)){
      System.out.println("number3 is greater than number");
    }
    number.subtract(number3);
    number.printNumber();
    
    System.out.println("Number has a size of " + number.getSize());
    System.out.println("Number2 has a size of " + number2.getSize());
    System.out.println("Number3 has a size of " + number3.getSize());
    */
    /*if(number2.isGreaterThan(number)){
      System.out.println("number2 is greater than number");
    }
    if(number2.isLessThan(number)){
      System.out.println("number2 is less than number");
    }
    if(number.isEqualTo(number2)){
      System.out.println("number2 is equal to number");
    }
    
    number.add(number2);
    number.printNumber();
    
    if(number.isGreaterThan(number2)){
      System.out.println("number is greater than number2");
    }
    if(number2.isLessThan(number)){
      System.out.println("number2 is less than number");
    }
    if(number.isEqualTo(number2)){
      System.out.println("number2 is equal to number");
    }
    
    
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number2.printNumber();
    number2.add(number);
    number2.printNumber();
    
    System.out.println("Number has a size of " + number.getSize());
    System.out.println("Number2 has a size of " + number2.getSize());
    */
  }
  
  public RSAProgram()
  {
    
    super("RSA Program");
    fileChosen = false;
    
    ButtonHandler buttonHandler = new ButtonHandler();
    
    Container container = getContentPane();
    JPanel panel1 = new JPanel();
    panel1.setLayout(new BorderLayout());
    JPanel panel2 = new JPanel();
    JPanel panel3 = new JPanel();
    panel3.setLayout(new BorderLayout());
    JPanel panel4 = new JPanel();
    panel4.setLayout(new FlowLayout());
    JPanel panel5 = new JPanel();
    panel5.setLayout(new BorderLayout());
    
    
    createKey = new JButton("Create RSA keys");
    createKey.addActionListener(buttonHandler);
    panel1.add(createKey);
    container.add(panel1,BorderLayout.WEST);
    
    
    blockFile = new JButton("Block File");
    blockFile.addActionListener(buttonHandler);
    panel2.add(blockFile);
    unBlock = new JButton("Unblock File");
    unBlock.addActionListener(buttonHandler);
    panel2.add(unBlock);
    panel1.add(panel2,BorderLayout.SOUTH);
    
    encrypt = new JButton("Encrypt");
    encrypt.addActionListener(buttonHandler);
    decrypt = new JButton("Decrypt");
    decrypt.addActionListener(buttonHandler);
    panel3.add(encrypt,BorderLayout.WEST);
    panel3.add(decrypt,BorderLayout.EAST);
    container.add(panel3,BorderLayout.EAST);
    
    fileNameLabel = new JLabel("No file chosen.");
    panel4.add(fileNameLabel);
    chooseFile = new JButton("Choose File");
    chooseFile.addActionListener(buttonHandler);
    panel4.add(chooseFile);
    container.add(panel4,BorderLayout.NORTH);
    
    lastAction = new JLabel("Start by creating an RSA key.");
    panel5.add(lastAction,BorderLayout.WEST);
    container.add(panel5,BorderLayout.SOUTH);
    
    setSize(500, 250);
    setVisible(true);
      
  }
  
  public class ButtonHandler implements ActionListener{
    public void actionPerformed(ActionEvent e) {
      
      if (e.getSource() == chooseFile){
        JFileChooser chooser = new JFileChooser(".\\");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files (*.txt, *.text)", "txt", "text");
        chooser.setFileFilter(filter);
        int success = chooser.showOpenDialog(null);
        
        if(success == JFileChooser.APPROVE_OPTION){
          if(chooser.getSelectedFile().getName().contains(".txt")){
            fileName = chooser.getSelectedFile().getName();
            currFile = chooser.getSelectedFile();
            fileNameLabel.setText(fileName);
            fileChosen = true;
          }
          else{
            JOptionPane.showMessageDialog(null, "Could not open file...");
          }
        }
      }
      
      if (e.getSource() == createKey){
        //JOptionPane.showMessageDialog(null, "createKey");
        generateKeys();
        lastAction.setText("creating keys...");
        
        //add code here
        
        lastAction.setText("Keys created, make sure you choose a file.");
      }
      
      if (e.getSource() == blockFile){
        //JOptionPane.showMessageDialog(null, "Block file");
        if(fileChosen){
          lastAction.setText("blocking file...");
        
          blocked(fileName, 8);
        
          lastAction.setText("File blocked.");
        }
        else{
          JOptionPane.showMessageDialog(null, "Choose a file first.");
        }
      }
      
      if (e.getSource() == unBlock){
        //JOptionPane.showMessageDialog(null, "Unblock");
        lastAction.setText("unblocking file...");
        
        unblocked(fileName, 8);
        
        lastAction.setText("File unblocked.");
      }
      
      if (e.getSource() == encrypt){
        //JOptionPane.showMessageDialog(null, "encrypt");
        lastAction.setText("encrypting file...");
        
        //add code here
        
        lastAction.setText("File encrypted.");
      }
      
      if (e.getSource() == decrypt){
        //JOptionPane.showMessageDialog(null, "decrypt");
        lastAction.setText("decrypting file...");
        
        //add code here
        
        lastAction.setText("File decrypted.");
      }
      
    }
  }
  public static void blocked(String filename, int blockSize) //block method
  {
    Path path = Paths.get(filename); //looks for file by this name in current working directory unless a specific
    //directory is given
    int blockSz = blockSize;
    try  //the given block size
    {
      byte[] bytesArray = Files.readAllBytes(path); //read the contents of the file
      
      int arraySize = bytesArray.length; //size of all array containing contents of the entire file
      int BlockIndex = 0;//index to keep track of how many chars we need to form a block
      byte[] line = new byte[8];//char to build blocked line
      String blockedLine;//string to convert the array to proper form
      
      String builtRev = ""; //the block now built in reverse
      byte addedByte; //used to build a string one byte at a time
      
      PrintWriter writer = new PrintWriter("OutputBlocking.txt", "UTF-8");
      for(int i = 0; i < arraySize; i++) //go through the entire array
      {
        line[BlockIndex] = bytesArray[i]; //build a block in an array
        BlockIndex++;
        int midpoint = 0; //midpoint of block
        midpoint = blockSize/2;
        if(BlockIndex == blockSz || i == (arraySize-1)) //we have built a block of size blockSize
        {
          if(i == (arraySize-1)) //we need to pad the remaining block
          {
            int padCount = blockSize - BlockIndex;
            for(int z = 0; z < padCount; z++)
            {
              line[z+BlockIndex] = 0;
            }
          }
          builtRev = "";
          for(int j = 0; j < midpoint; j++) //reverse the string
          {
            byte temp = line[j];
            line[j] = line[blockSz-1-j];
            line[blockSz-1-j] = temp;
          }
          BlockIndex = 0; //reset the index

          for(int t = 0; t < blockSz; t++)
          {
            addedByte = (byte)line[t];
            if(addedByte < 37) //add a 0 in front of added byte when our new ascii will be less than 10
            {
              builtRev += 0;
            }
            if(addedByte < 14) //set special chars
            {
              if(addedByte == 9)
              {
                addedByte = 2;
              }
              if(addedByte == 10)
              {
                addedByte = 3;
              }
              if(addedByte == 11)
              {
                addedByte = 1;
              }
              if(addedByte ==13)
              {
                addedByte = 4;
              }
            }
            else
            {
              addedByte -= 27; //calculate new ascii alphabet
            }
            builtRev += addedByte; 
          }//we can now write builtrev to file
          System.out.println(builtRev); //PROOF OF Q
          writer.println(builtRev);
        }
      }
      writer.close();
    } 
    catch (IOException e) 
    {
      System.out.println(e);
    }
  }
  public static void unblocked(String filename, int blockSize)
  {
    int blockSz = blockSize;
    String returnString = ""; //string we will write to file
    try 
    {
      File file = new File(filename);
      FileReader fileReader = new FileReader(file);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      //StringBuffer stringBuffer = new StringBuffer();
      String line; //line read in
      String bline = ""; //built line;
      while ((line = bufferedReader.readLine()) != null) 
      {
        bline += line;
      }
      
      fileReader.close();
      char[] cArray = bline.toCharArray(); //turn string into char array to iterate through it char by char
      
      for(int t = 0; t < cArray.length; t++)
      {
        //System.out.println(cArray[t]);
      }
      String parse = "";
      int BlockIndex = 0; //an index to keep track of what char to take
      int offset = 0; //offset by wh
      int currByte = 0; //which byte to grab from 15 next bytes

      for(int i = 0; i < cArray.length; i +=2)
      {
        parse = "";
        offset = ((2*blockSz)-1)+(((2*blockSz))*(i/((2*blockSz))));
        currByte = (BlockIndex*2);
        parse += cArray[(offset-(currByte+1))];
        parse += cArray[(offset-(currByte))];

        //System.out.println(parse);
        int x = Integer.parseInt(parse);
        if(x != 0)
        {
        if(x<5)
        {
          if(x == 2)
          {
            x = 9;
          }
          if(x == 3)
          {
            x = 10;
          }
          if(x == 1)
          {
            x = 11;
          }
          if(x ==4)
          {
            x = 13;
          }
        }
        else
        {
          x +=27;
        }
        char b = (char)x;
        //System.out.println(b);
        returnString += b;
        //System.out.println(returnString);
        }
        BlockIndex++;
        if(BlockIndex == (blockSz))
        {
          BlockIndex = 0;
        }
      }
      PrintWriter writer = new PrintWriter("OutputUnblocking.txt", "UTF-8");
      writer.println(returnString);
      writer.close();
  } 
   catch (IOException e) 
   {
     e.printStackTrace();
   }
  }
  public static String getRandom(String filename, int blockSize)
  { //include the info for this file in the readMe
    //to grab random number, generate a random number X and read X times(line by line)'
    //from the file(as a line) and parse to line as Int.
    String line = ""; //line read in
    try 
    {
      Random rand = new Random(); 
      File file = new File(filename);
      FileReader fileReader = new FileReader(file);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
    
      int value = rand.nextInt(20)+2; 
    
      for(int i = 0; i < value; i++)
      {
       line = bufferedReader.readLine();
      }
      fileReader.close();
    } 
    catch (IOException e) 
    {
      e.printStackTrace();
    }
    //long a = Long.parseLong(line);
    return line;
  }
  public static void generateKeys()
  {
    String p = getRandom("BigPrimes.txt", 15); //get random p
    String q = getRandom("BigPrimes.txt", 15); //get random q
    IntArrClass P = new IntArrClass(p); //init P
    IntArrClass Q = new IntArrClass(q); //init Q
    IntArrClass N = new IntArrClass(q); //inti N
    IntArrClass one = new IntArrClass(1); //inti N
    IntArrClass one2 = new IntArrClass(1); //inti N
    IntArrClass one3 = new IntArrClass(1); //inti N
    N.multiply(Q); //calculate P*Q
    IntArrClass PHI = new IntArrClass(0);
    //System.out.println("P: ");
    P.printNumber();
    //System.out.println("Q: ");
    Q.printNumber();
    
    Q.subtract(one);
    P.subtract(one2);
    
    
    System.out.println("P-1: ");
    P.printNumber();
    System.out.println("Q-1: ");
    Q.printNumber();
    
    PHI.setEqualTo(P);
    PHI.multiply(Q);

    IntArrClass J = new IntArrClass(0);

    IntArrClass zero = new IntArrClass(0);
    J.add(N);
    J.subtract(one3); //j is now n-1, this is where we begin to look for e
    IntArrClass E = new IntArrClass(0);
    IntArrClass GCD = new IntArrClass(0);
    while(J.isGreaterThan(zero)) //while j is greater than 0
    {
      System.out.println("J");
      J.printNumber();
      
      //calculate gcd
      if(GCD.isEqualTo(one) == true) //find an e < 1 that is relatv. prime to phi
      {
        GCD.add(gcd(PHI, J));
        E.add(J);//set e equal to J
        break; //break now that we have the e
      }
      J.subtract(one); //decrement j
      GCD.reset();   //set GCD back to 0;
    }
    IntArrClass D = new IntArrClass(0);
    D.setEqualTo(modMultInverse(E,PHI));

    System.out.println("D: ");
    D.printNumber();             

  } 
  public static IntArrClass gcd(IntArrClass A, IntArrClass B) 
  {
    IntArrClass a = new IntArrClass(0);
    IntArrClass b = new IntArrClass(0);
    a.add(A);
    b.add(B);
      
      while (a.isEqualTo(b) == false) //while a/b are not equal subtract a/b from b/a
      {
         if (a.isGreaterThan(b))   
         { 
           a.subtract(b); 
         }
         else 
         { 
           b.subtract(a); 
         }
      }
      return a;
   } //reference: http://www.naturalnumbers.org/EuclidSubtract.html

  public static void writeToXML(long Ed, long n, String eD, String filename)
  {
    String eVal = Long.toString(Ed);
    String nVal = Long.toString(n);
      
    try 
    {
      DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
      Document doc = docBuilder.newDocument();
      Element rootElement = doc.createElement("rsakey");
      doc.appendChild(rootElement);
      
      Element evalue = doc.createElement(eD);
      evalue.appendChild(doc.createTextNode(eVal));
      rootElement.appendChild(evalue);
      
      Element nvalue = doc.createElement("nvalue");
      nvalue.appendChild(doc.createTextNode(nVal));
      rootElement.appendChild(nvalue);
    
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      DOMSource source = new DOMSource(doc);
      StreamResult result = new StreamResult(new File(filename));
      transformer.transform(source, result);
      System.out.println("File saved!");
    } 
    
    catch (ParserConfigurationException pce) 
    {
      pce.printStackTrace();
    } 
    catch (TransformerException tfe) 
    {
      tfe.printStackTrace();
    }
  }
  
  public static String[] getXMLKeys(String filename)
  {
          String Keys[] = new String[2];
      Keys[0] = "";
      Keys[1] = "";
    try 
    {
         File file = new File(filename);
         DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
        .newInstance();
         DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
         Document document = documentBuilder.parse(file);
         String evalue = document.getElementsByTagName("evalue").item(0).getTextContent();
         String dvalue = document.getElementsByTagName("dvalue").item(0).getTextContent();
         String nvalue = document.getElementsByTagName("nvalue").item(1).getTextContent();
         if(evalue == null)
         {
           Keys[0] = dvalue;
         }
         else
         {
           Keys[0] = evalue;
         }
         Keys[1] = nvalue;

         System.out.println(nvalue); 

    } 
    catch (Exception e) 
    {
      System.out.println(e.getMessage());
    }
    return Keys;
  }
    void rsa_algorithm(IntArrClass x)
    {
      //if we pass in D flag, set ed var to D
      //else set the var to E
      //read in the key
      //
      //d/encryption
      //M = C^dmod n
      //take the value at the blocked line
      //make it an IntArrClass
      //do the D/E
      //write it to file
      //return 0;
      //IntArrClass one = new IntArrClass()
    }

    static IntArrClass modMultInverse(IntArrClass e,IntArrClass phi)
    {
      e.mod(phi);
      IntArrClass x = new IntArrClass(1);
      x.printNumber();
      IntArrClass temp = new IntArrClass(0);
      IntArrClass temp1 = new IntArrClass(0);
      IntArrClass temp2 = new IntArrClass(0);
      IntArrClass temp3 = new IntArrClass(0);
      IntArrClass temp4 = new IntArrClass(0);
      IntArrClass temp5 = new IntArrClass(0);
      IntArrClass temp6 = new IntArrClass(0);
      IntArrClass zero = new IntArrClass(0);
      IntArrClass one = new IntArrClass(1);
      IntArrClass xholder = new IntArrClass(0);
      int o = 0;
      
      while(x.isLessThan(phi)) //brute force find d key
      {System.out.println("==============================================");
        xholder.setEqualTo(x); //x
        System.out.println("xholder");
        xholder.printNumber();
        temp1.setEqualTo(e);   //e
        System.out.println("temp1");
        temp1.printNumber();
        temp2.setEqualTo(phi); //phi
        System.out.println("temp2");
        temp2.printNumber();
        temp.setEqualTo(temp1);
        System.out.println("temp");
        temp.printNumber();
        temp.multiply(xholder); //e*m
        System.out.println("temp");
        temp.printNumber();
        temp3.setEqualTo(temp);
        temp3.mod(temp2);
        System.out.println("temp3");
        temp3.printNumber();
        
        if(temp3.isEqualTo(one)== true) //found d key
        {
          break;
        }
        if(o == 20)
        {
          break;
        }
        o++;
        x.increment();
        System.out.println("dKEY");
      x.printNumber();
      }
      System.out.println("dKEY");
      x.printNumber();
      return x;
    }
}

  