import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.io.*;
import javax.swing.filechooser.*;

public class RSAProgram extends JFrame{
  private JButton createKey, blockFile, unBlock, encrypt, decrypt, chooseFile;
  private JLabel fileNameLabel;
  private JLabel lastAction;
  private String fileName;
  private File currFile;
  private boolean fileChosen;
  
  public static void main(String[] args){
   
    RSAProgram frame = new RSAProgram();
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    
    System.out.println("Let's get started...");
    
    IntArrClass number = new IntArrClass(999999998);
    IntArrClass number2 = new IntArrClass(9231993);
    IntArrClass number3 = new IntArrClass(4110441);
    IntArrClass number4 = new IntArrClass(9222993);
    IntArrClass number5 = new IntArrClass(4110441);
    IntArrClass number6 = new IntArrClass(8220882);
    IntArrClass number7 = new IntArrClass(8220882);
    number.printNumber();
    
    number2.multiply(new IntArrClass(2));
    
    IntArrClass number23 = new IntArrClass(23);
    IntArrClass numberNew2 = new IntArrClass(2);
    IntArrClass numberNew3 = new IntArrClass(3);
    
    number.mod(numberNew3).printNumber();
    number.divide(numberNew3);
    number.printNumber();
    
    number23.mod(numberNew2).printNumber();
    number23.divide(numberNew2);
    number23.printNumber();
    
    number2.divide(number3);
    number2.printNumber();
    
    /*number.multiply(new IntArrClass(999999999));
    number.printNumber();
    System.out.println("Number has a size of " + number.getSize());
    */
    
    /*number.add(number2);
    number.printNumber();
    
    number.subtract(number2);
    number.printNumber();
    number.subtract(number3);
    number.printNumber();
    number.subtract(number3);
    number.printNumber();
    if(number3.isGreaterThan(number)){
      System.out.println("number3 is greater than number");
    }
    number.subtract(number3);
    number.printNumber();
    
    System.out.println("Number has a size of " + number.getSize());
    System.out.println("Number2 has a size of " + number2.getSize());
    System.out.println("Number3 has a size of " + number3.getSize());
    */
    /*if(number2.isGreaterThan(number)){
      System.out.println("number2 is greater than number");
    }
    if(number2.isLessThan(number)){
      System.out.println("number2 is less than number");
    }
    if(number.isEqualTo(number2)){
      System.out.println("number2 is equal to number");
    }
    
    number.add(number2);
    number.printNumber();
    
    if(number.isGreaterThan(number2)){
      System.out.println("number is greater than number2");
    }
    if(number2.isLessThan(number)){
      System.out.println("number2 is less than number");
    }
    if(number.isEqualTo(number2)){
      System.out.println("number2 is equal to number");
    }
    
    
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number.add(number2);
    number.printNumber();
    number2.printNumber();
    number2.add(number);
    number2.printNumber();
    
    System.out.println("Number has a size of " + number.getSize());
    System.out.println("Number2 has a size of " + number2.getSize());
    */
  }
  
  public RSAProgram()
  {
    
    super("RSA Program");
    fileChosen = false;
    
    ButtonHandler buttonHandler = new ButtonHandler();
    
    Container container = getContentPane();
    JPanel panel1 = new JPanel();
    panel1.setLayout(new BorderLayout());
    JPanel panel2 = new JPanel();
    JPanel panel3 = new JPanel();
    panel3.setLayout(new BorderLayout());
    JPanel panel4 = new JPanel();
    panel4.setLayout(new FlowLayout());
    JPanel panel5 = new JPanel();
    panel5.setLayout(new BorderLayout());
    
    
    createKey = new JButton("Create RSA keys");
    createKey.addActionListener(buttonHandler);
    panel1.add(createKey);
    container.add(panel1,BorderLayout.WEST);
    
    
    blockFile = new JButton("Block File");
    blockFile.addActionListener(buttonHandler);
    panel2.add(blockFile);
    unBlock = new JButton("Unblock File");
    unBlock.addActionListener(buttonHandler);
    panel2.add(unBlock);
    panel1.add(panel2,BorderLayout.SOUTH);
    
    encrypt = new JButton("Encrypt");
    encrypt.addActionListener(buttonHandler);
    decrypt = new JButton("Decrypt");
    decrypt.addActionListener(buttonHandler);
    panel3.add(encrypt,BorderLayout.WEST);
    panel3.add(decrypt,BorderLayout.EAST);
    container.add(panel3,BorderLayout.EAST);
    
    fileNameLabel = new JLabel("No file chosen.");
    panel4.add(fileNameLabel);
    chooseFile = new JButton("Choose File");
    chooseFile.addActionListener(buttonHandler);
    panel4.add(chooseFile);
    container.add(panel4,BorderLayout.NORTH);
    
    lastAction = new JLabel("Start by creating an RSA key.");
    panel5.add(lastAction,BorderLayout.WEST);
    container.add(panel5,BorderLayout.SOUTH);
    
    setSize(500, 250);
    setVisible(true);
      
  }
  
  public class ButtonHandler implements ActionListener{
    public void actionPerformed(ActionEvent e) {
      
      if (e.getSource() == chooseFile){
        JFileChooser chooser = new JFileChooser(".\\");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files (*.txt, *.text)", "txt", "text");
        chooser.setFileFilter(filter);
        int success = chooser.showOpenDialog(null);
        
        if(success == JFileChooser.APPROVE_OPTION){
          if(chooser.getSelectedFile().getName().contains(".txt")){
            fileName = chooser.getSelectedFile().getName();
            currFile = chooser.getSelectedFile();
            fileNameLabel.setText(fileName);
            fileChosen = true;
          }
          else{
            JOptionPane.showMessageDialog(null, "Could not open file...");
          }
        }
      }
      
      if (e.getSource() == createKey){
        //JOptionPane.showMessageDialog(null, "createKey");
        lastAction.setText("creating keys...");
        
        //add code here
        
        lastAction.setText("Keys created, make sure you choose a file.");
      }
      
      if (e.getSource() == blockFile){
        //JOptionPane.showMessageDialog(null, "Block file");
        if(fileChosen){
          lastAction.setText("blocking file...");
        
          //add code here
        
          lastAction.setText("File blocked.");
        }
        else{
          JOptionPane.showMessageDialog(null, "Choose a file first.");
        }
      }
      
      if (e.getSource() == unBlock){
        //JOptionPane.showMessageDialog(null, "Unblock");
        lastAction.setText("unblocking file...");
        
        //add code here
        
        lastAction.setText("File unblocked.");
      }
      
      if (e.getSource() == encrypt){
        //JOptionPane.showMessageDialog(null, "encrypt");
        lastAction.setText("encrypting file...");
        
        //add code here
        
        lastAction.setText("File encrypted.");
      }
      
      if (e.getSource() == decrypt){
        //JOptionPane.showMessageDialog(null, "decrypt");
        lastAction.setText("decrypting file...");
        
        //add code here
        
        lastAction.setText("File decrypted.");
      }
      
    }
  }
}

  