import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Random;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import java.util.Scanner;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Test
{  
  public static void main(String[] args)
  {

    //generateKeys("rubio.txt", 8);
    blocked("testDoc.txt", 8);
    //IntArrClass E = new IntArrClass(79);
    //IntArrClass phiN = new IntArrClass(3220);
    //modMultInverse(E, phiN);
    
  }
  public static void blocked(String filename, int blockSize) //block method
  {
    Path path = Paths.get(filename); //looks for file by this name in current working directory unless a specific
    //directory is given
    int blockSz = blockSize;
    try  //the given block size
    {
      byte[] bytesArray = Files.readAllBytes(path); //read the contents of the file
      
      int arraySize = bytesArray.length; //size of all array containing contents of the entire file
      int BlockIndex = 0;//index to keep track of how many chars we need to form a block
      byte[] line = new byte[8];//char to build blocked line
      String blockedLine;//string to convert the array to proper form
      
      String builtRev = ""; //the block now built in reverse
      byte addedByte; //used to build a string one byte at a time
      
      PrintWriter writer = new PrintWriter("OutputBlocking.txt", "UTF-8");
      for(int i = 0; i < arraySize; i++) //go through the entire array
      {
        line[BlockIndex] = bytesArray[i]; //build a block in an array
        BlockIndex++;
        int midpoint = 0; //midpoint of block
        midpoint = blockSize/2;
        if(BlockIndex == blockSz || i == (arraySize-1)) //we have built a block of size blockSize
        {
          if(i == (arraySize-1)) //we need to pad the remaining block
          {
            int padCount = blockSize - BlockIndex;
            for(int z = 0; z < padCount; z++)
            {
              line[z+BlockIndex] = 0;
            }
          }
          builtRev = "";
          for(int j = 0; j < midpoint; j++) //reverse the string
          {
            byte temp = line[j];
            line[j] = line[blockSz-1-j];
            line[blockSz-1-j] = temp;
          }
          BlockIndex = 0; //reset the index

          for(int t = 0; t < blockSz; t++)
          {
            addedByte = (byte)line[t];
            if(addedByte < 37) //add a 0 in front of added byte when our new ascii will be less than 10
            {
              builtRev += 0;
            }
            if(addedByte < 14) //set special chars
            {
              if(addedByte == 9)
              {
                addedByte = 2;
              }
              if(addedByte == 10)
              {
                addedByte = 3;
              }
              if(addedByte == 11)
              {
                addedByte = 1;
              }
              if(addedByte ==13)
              {
                addedByte = 4;
              }
            }
            else
            {
              addedByte -= 27; //calculate new ascii alphabet
            }
            builtRev += addedByte; 
          }//we can now write builtrev to file
          //System.out.println(builtRev); //PROOF OF Q
          //writer.println(builtRev);
        }
      }
      writer.close();
    } 
    catch (IOException e) 
    {
      System.out.println(e);
    }
  }
  public static void unblocked(String filename, int blockSize)
  {
    int blockSz = blockSize;
    String returnString = ""; //string we will write to file
    try 
    {
      File file = new File(filename);
      FileReader fileReader = new FileReader(file);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      //StringBuffer stringBuffer = new StringBuffer();
      String line; //line read in
      String bline = ""; //built line;
      while ((line = bufferedReader.readLine()) != null) 
      {
        bline += line;
      }
      
      fileReader.close();
      char[] cArray = bline.toCharArray(); //turn string into char array to iterate through it char by char
      
      for(int t = 0; t < cArray.length; t++)
      {
        //System.out.println(cArray[t]);
      }
      String parse = "";
      int BlockIndex = 0; //an index to keep track of what char to take
      int offset = 0; //offset by wh
      int currByte = 0; //which byte to grab from 15 next bytes

      for(int i = 0; i < cArray.length; i +=2)
      {
        parse = "";
        offset = ((2*blockSz)-1)+(((2*blockSz))*(i/((2*blockSz))));
        currByte = (BlockIndex*2);
        parse += cArray[(offset-(currByte+1))];
        parse += cArray[(offset-(currByte))];

        //System.out.println(parse);
        int x = Integer.parseInt(parse);
        if(x != 0)
        {
        if(x<5)
        {
          if(x == 2)
          {
            x = 9;
          }
          if(x == 3)
          {
            x = 10;
          }
          if(x == 1)
          {
            x = 11;
          }
          if(x ==4)
          {
            x = 13;
          }
        }
        else
        {
          x +=27;
        }
        char b = (char)x;
        //System.out.println(b);
        returnString += b;
        //System.out.println(returnString);
        }
        BlockIndex++;
        if(BlockIndex == (blockSz))
        {
          BlockIndex = 0;
        }
      }
      PrintWriter writer = new PrintWriter("OutputUnblocking.txt", "UTF-8");
      //writer.println(returnString);
      writer.close();
  } 
   catch (IOException e) 
   {
     e.printStackTrace();
   }
  }
  public static String getRandom(String filename, int blockSize)
  { //include the info for this file in the readMe
    //to grab random number, generate a random number X and read X times(line by line)'
    //from the file(as a line) and parse to line as Int.
    String line = ""; //line read in
    try 
    {
      Random rand = new Random(); 
      File file = new File(filename);
      FileReader fileReader = new FileReader(file);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
    
      int value = rand.nextInt(20)+2; 
    
      for(int i = 0; i < value; i++)
      {
       line = bufferedReader.readLine();
      }
      fileReader.close();
    } 
    catch (IOException e) 
    {
      e.printStackTrace();
    }
    //long a = Long.parseLong(line);
    return line;
  }
  public static void generateKeys(String filename, int blockSize)
  {
    String p = getRandom("BigPrimes.txt", 15); //get random p
    String q = getRandom("BigPrimes.txt", 15); //get random q
    IntArrClass P = new IntArrClass(p); //init P
    IntArrClass Q = new IntArrClass(q); //init Q
    IntArrClass N = new IntArrClass(q); //inti N
    IntArrClass one = new IntArrClass(1); //inti N
    IntArrClass one2 = new IntArrClass(1); //inti N
    IntArrClass one3 = new IntArrClass(1); //inti N
    N.multiply(Q); //calculate P*Q
    //long p1 = Long.valueOf(p); //value of p-1
    //long q1 = Long.valueOf(q); //value of q-1
    //p1--;
    //q1--;
    //String P1 = String.valueOf(p1);
    //String Q1 = String.valueOf(q1);
    IntArrClass PHI = new IntArrClass(0);
    //IntArrClass Q11 = new IntArrClass(q1); //value of q1
    System.out.println("P: ");
    P.printNumber();
    System.out.println("Q: ");
    Q.printNumber();
    
    Q.subtract(one);
    P.subtract(one2);
    
    
    System.out.println("P-1: ");
    P.printNumber();
    System.out.println("Q-1: ");
    Q.printNumber();
    
    PHI.setEqualTo(P);
    PHI.multiply(Q);

    IntArrClass J = new IntArrClass(0);

    IntArrClass zero = new IntArrClass(0);
    J.add(N);
    J.subtract(one3); //j is now n-1, this is where we begin to look for e
    IntArrClass E = new IntArrClass(0);
    IntArrClass GCD = new IntArrClass(0);
    while(J.isGreaterThan(zero)) //while j is greater than 0
    {
      System.out.println("J");
      J.printNumber();
      
      //calculate gcd
      if(GCD.isEqualTo(one) == true) //find an e < 1 that is relatv. prime to phi
      {
        GCD.add(gcd(PHI, J));
        E.add(J);//set e equal to J
        break; //break now that we have the e
      }
      J.subtract(one); //decrement j
      GCD.reset();   //set GCD back to 0;
    }
    IntArrClass D = new IntArrClass(0);
    D.setEqualTo(modMultInverse(E,PHI));

    System.out.println("D: ");
    D.printNumber();             

  } 
  public static IntArrClass gcd(IntArrClass A, IntArrClass B) 
  {
    IntArrClass a = new IntArrClass(0);
    IntArrClass b = new IntArrClass(0);
    a.add(A);
    b.add(B);
      
      while (a.isEqualTo(b) == false) //while a/b are not equal subtract a/b from b/a
      {
         if (a.isGreaterThan(b))   
         { 
           a.subtract(b); 
         }
         else 
         { 
           b.subtract(a); 
         }
      }
      return a;
   } //reference: http://www.naturalnumbers.org/EuclidSubtract.html

  public static void writeToXML(long Ed, long n, String eD, String filename)
  {
    String eVal = Long.toString(Ed);
    String nVal = Long.toString(n);
      
    try 
    {
      DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
      Document doc = docBuilder.newDocument();
      Element rootElement = doc.createElement("rsakey");
      doc.appendChild(rootElement);
      
      Element evalue = doc.createElement(eD);
      evalue.appendChild(doc.createTextNode(eVal));
      rootElement.appendChild(evalue);
      
      Element nvalue = doc.createElement("nvalue");
      nvalue.appendChild(doc.createTextNode(nVal));
      rootElement.appendChild(nvalue);
    
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      DOMSource source = new DOMSource(doc);
      StreamResult result = new StreamResult(new File(filename));
      transformer.transform(source, result);
      System.out.println("File saved!");
    } 
    
    catch (ParserConfigurationException pce) 
    {
      pce.printStackTrace();
    } 
    catch (TransformerException tfe) 
    {
      tfe.printStackTrace();
    }
  }
  
  public static String[] getXMLKeys(String filename)
  {
          String Keys[] = new String[2];
      Keys[0] = "";
      Keys[1] = "";
    try 
    {
         File file = new File(filename);
         DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
        .newInstance();
         DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
         Document document = documentBuilder.parse(file);
         String evalue = document.getElementsByTagName("evalue").item(0).getTextContent();
         String dvalue = document.getElementsByTagName("dvalue").item(0).getTextContent();
         String nvalue = document.getElementsByTagName("nvalue").item(1).getTextContent();
         if(evalue == null)
         {
           Keys[0] = dvalue;
         }
         else
         {
           Keys[0] = evalue;
         }
         Keys[1] = nvalue;

         System.out.println(nvalue); 

    } 
    catch (Exception e) 
    {
      System.out.println(e.getMessage());
    }
    return Keys;
  }
    void rsa_algorithm(IntArrClass x)
    {
      //if we pass in D flag, set ed var to D
      //else set the var to E
      //read in the key
      //
      //d/encryption
      //M = C^dmod n
      //take the value at the blocked line
      //make it an IntArrClass
      //do the D/E
      //write it to file
      //return 0;
      //IntArrClass one = new IntArrClass()
    }

    static IntArrClass modMultInverse(IntArrClass e,IntArrClass phi)
    {
      e.mod(phi);
      IntArrClass x = new IntArrClass(1);
      x.printNumber();
      IntArrClass temp = new IntArrClass(0);
      IntArrClass temp1 = new IntArrClass(0);
      IntArrClass temp2 = new IntArrClass(0);
      IntArrClass zero = new IntArrClass(0);
      IntArrClass one = new IntArrClass(1);
      IntArrClass xholder = new IntArrClass(0);
      
      
      while(x.isLessThan(phi))
      {
        xholder.setEqualTo(x);
        temp1.setEqualTo(e); 
        temp.setEqualTo(temp1);
        temp.setEqualTo(temp2);
        temp.multiply(xholder);
        temp.printNumber();
        //temp.clearZeroes();
        temp.mod(phi);
        temp.clearZeroes();
        
        if(temp.isEqualTo(one)== true)  
        {
          break;
        }
        
        x.increment();
      }
      x.printNumber();
      return x;
    }
}