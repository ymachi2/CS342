Factory Design Pattern employed in the TetFactory class 
in order to randomly choose between and spawn each of the
seven tetrominoe pieces.

Singleton Design Pattern used for the TetrisGrid object and 
class to ensure it is the only object of its kind in the
entire program.

Extra Credit: Holding the down key allows for softSkip functionality