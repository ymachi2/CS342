import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class blockPositions
{
  private int x;
  private int y;
  
  public blockPositions()
  {
    x = 0;
    y = 0;
  }
  
  public int getX()
  {
    return x;
  }
  public int getY()
  {
    return y;
  }
  public void setX(int X)
  {
    x = X;
  }
  public void setY(int Y)
  {
    y = Y;
  }
  
  public void setDim(int X, int Y)
  {
    x = X;
    y = Y;
  }
}