import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TetrisTile extends JButton 
{
  private int row;
  private int col;
  protected String state;
  private Icon icon;
  
  public TetrisTile(int r, int c, String s, Icon i)
  {
    super("", i);
    this.state = s;
    this.row = r;
    this.col = c;
  }
  
  public void setState(String s)
  {
    this.state = s;
  }  
  
  public String getState()
  {
    return this.state;
  }
  
  /*public Icon getIcon()
  {
    return this.icon;
  }*/
  
  public int getRow()
  {
    return this.row;
  }  
  public int getCol()
  {
    return this.col;
  }  
  
}
