

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.event.*;


public class gui {

 private JFrame frame; //game frame
 private JMenuBar menuBar; //menu bar
 private JMenu gameMenu;  //game menu
 private JMenu helpMenu;  //help menu
 private JMenuItem Start, Reset, exit;  //game menu items
 private JMenuItem about, help;  //help menu items
 private JPanel clockP, panel, scoreP;  //panel for clock
 private JLabel clock, score;  //label for clock
 private Timer time;  //timer
 private int seconds = 0;  //seconds
 private TetrisGrid game = TetrisGrid.getInstance(); //game grid


/******************************************************************/
 
 //The design for the entire game
 public void Design(){
   
   //Frame
  frame = new JFrame("Tetris");
  frame.setResizable(false);
  menuBar = new JMenuBar();

  // Game Menu, G - Mnemonic
  gameMenu = new JMenu("Game");
  gameMenu.setMnemonic(KeyEvent.VK_F);
  menuBar.add(gameMenu);
  
    //Help Menu, H - Mnemonic
  helpMenu = new JMenu("Help");
  helpMenu.setMnemonic(KeyEvent.VK_F);
  menuBar.add(helpMenu);
  
    // GAME MENU ITEMS
  Start = new JMenuItem("Start", KeyEvent.VK_N); //S - Mnemonic
  Start.addActionListener(new MenuActionListener());
  Reset = new JMenuItem("Reset", KeyEvent.VK_N);  //R - Mnemonic
  Reset.addActionListener(new MenuActionListener());
  exit = new JMenuItem("eXit", KeyEvent.VK_N);  //X - Mnemonic
  exit.addActionListener(new MenuActionListener());
  gameMenu.add(Start);
  gameMenu.add(Reset);
  gameMenu.add(exit);

    //HELP MENU ITEMS
  help = new JMenuItem("Help", KeyEvent.VK_N);
  help.addActionListener(new MenuActionListener());
  about = new JMenuItem("About", KeyEvent.VK_N);
  about.addActionListener(new MenuActionListener());
  helpMenu.add(help);
  helpMenu.add(about);
  
  
//Clock Layout/ Score...
  clockP = new JPanel();
  clock = new JLabel();
  //clock.setText ("Time: " + seconds);
  clockP.add(clock);
  frame.getContentPane().add(clockP,BorderLayout.NORTH);
  
  
    //TIMER
  time = new Timer(1000, new timerActionListener(clock));
  //time.start();
  
 
  
  //GAME LAYOUT
  panel = new JPanel();
  panel.setSize(200,400);
  panel.add(game);
 // panel.setFocusable(true);
  panel.requestFocusInWindow();
  frame.getContentPane().add(panel,BorderLayout.CENTER);
  frame.pack();
  panel.setFocusable(true);
    
  panel.addKeyListener(new TAdapter());
  
  frame.setJMenuBar(menuBar);
  frame.setSize(400, 500);
  frame.setVisible(true);
 }

 //Main
 public static void main(String[] args)
 {
  SwingUtilities.invokeLater(new Runnable(){
    //runs the entire program
   public void run()
   {
     //My menu made from action class
    gui MyMenu = new gui();
    MyMenu.Design();

   }
  });
 }  //end main

 /******************************************************************/
 /******************************************************************/
 
 class MenuActionListener implements ActionListener {
   public void actionPerformed(ActionEvent e) {
     if ("Start".equals(e.getActionCommand())){

    System.out.println("Start has been pressed.");
    time.start();
    //start game
    game.startGame();
    Start.setEnabled(false);
    seconds = 0;  //reset timer
   }

    if ("Reset".equals(e.getActionCommand())){

    System.out.println("Reset has been pressed.");
    int dialogButton = JOptionPane.YES_NO_OPTION;
    int dialogResult = JOptionPane.showConfirmDialog (frame, "Are you sure you want to reset?","Warning",dialogButton);
    if(dialogResult == JOptionPane.YES_OPTION)
    {
     game.resetGrid();
     seconds = 0;
     
    }
   }
    if ("eXit".equals(e.getActionCommand())){
    int exitDialog = JOptionPane.YES_NO_OPTION;
    int ex = JOptionPane.showConfirmDialog (frame, "Are you sure you would like to exit?","Warning",exitDialog);
    if(ex == JOptionPane.YES_OPTION)
    {
     System.exit(0);
    }
    
   }
    
    if("Help".equals(e.getActionCommand())){
    JOptionPane.showMessageDialog(frame,
      "Tetris is a game that requires to strategically rotate and move Tetrominoes in order \n"
        + "to clear full horizontal rows to get points.  As the game progresses the speed at which\n"
        + "the Tetrominoes drop increases, making the game challenging.\n"
        + "If the blocks surpass the top of the game grid, GAME OVER!.\n",
        "Help",
        JOptionPane.PLAIN_MESSAGE);
   }
    
    if("About".equals(e.getActionCommand())){
    JOptionPane.showMessageDialog(frame,  "CS 342: Spring 2016 - Tetris\n"
      + "Author 1: Stephanie Melo"
      + " (User ID: emelo2)\n"
      + "Author 2: Yordan"
      + " (User ID: ymachi2)\n"
      + ""
      + "Due date: April 27, 2016 @ 11:59pm\n"
      + "This is a simple version of "
      + " Tetris."
      ,"About", JOptionPane.PLAIN_MESSAGE);

   }
  }
 }
 
 //Timer actionListener
 class timerActionListener implements ActionListener{
   private JLabel timerLabel;
   
   //constructor
   public timerActionListener(JLabel timerLabel){
     this.timerLabel = timerLabel;
   }        
   
   //actionPerformed to print out timer and score
   @Override
   public void actionPerformed (ActionEvent e){
     
       seconds++;
     
     //prints out the time elapsed, score and level
     this.timerLabel.setText("Time: " + seconds + "  Score: " + game.getScore() + "  Level: " + game.getLevel());
   }
 }
 
 class TAdapter extends KeyAdapter {
    
    public void keyPressed(KeyEvent e) {
      int c = e.getKeyCode();

      switch (c) {
        case KeyEvent.VK_LEFT:
          if(game.curr.moveLeft());
          break;
        case KeyEvent.VK_RIGHT:
          if(game.curr.moveRight());
          break;
        case KeyEvent.VK_DOWN:
          game.curr.moveDown();
          break;
        case KeyEvent.VK_UP:
          game.curr.rotateClock();
          break;
        case KeyEvent.VK_SPACE:
          game.curr.hardSkip();
          break;
        case 's':
          //slow
          break;
      }
      
    }
  }
 
 
 
}