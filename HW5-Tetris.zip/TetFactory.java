import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TetFactory{
  
  public Tetrominoe getTet(int x, TetrisTile[][] G)
  {
    if(x == 0)
    {
      return new iTetrominoe(G);
    }
    if(x == 1)
    {
      return new oTetrominoe(G);
    }
    if(x == 2)
    {
      return new tTetrominoe(G);
    }
    if(x == 3)
    {
      return new sTetrominoe(G);
    }
    if(x == 4)
    {
      return new zTetrominoe(G);
    }
    if(x == 5)
    {
      return new LTetrominoe(G);
    }
    if(x == 6)
    {
      return new backLTetrominoe(G);
    }
    
    return null;
  }
  
  interface Tetrominoe 
  {
    boolean insert();
    boolean moveDown();
    boolean moveLeft();
    boolean moveRight();
    void rotateClock();
    void rotateCounter();
    void hardSkip();
    void softSkip(boolean x);
  }
 
  class iTetrominoe implements Tetrominoe 
  {
    Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
    private blockPositions blocks[];
    private Icon blockColor;
    private TetrisTile[][] g;
    private boolean vertical;
    
    public iTetrominoe(TetrisTile[][] G)
    {
      blocks = new blockPositions[4];
      for(int i = 0; i < 4; ++i)
      {
        blocks[i] = new blockPositions();
      }
      
      blockColor = new ImageIcon( "TetrisImages/TetrisBlack.gif" );
      this.g = G;
      vertical = true;
    }
    
    public Icon getIcon()
    {
      return blockColor;
    }
    
    
    
    @Override
    public boolean insert()
    {
      boolean success = true;
      int x = g.length;
      int y = g[0].length;
      //System.out.println("dimensions of array are: " + x + "x" + y);
      
      if(!(g[0][y/2].getState().equals("background")) ||
         !(g[1][y/2].getState().equals("background")) ||
         !(g[2][y/2].getState().equals("background")) ||
         !(g[3][y/2].getState().equals("background"))   )
      {
        success = false;
      }
      
      blocks[0].setDim(0, y/2);
      blocks[1].setDim(1, y/2);
      blocks[2].setDim(2, y/2);
      blocks[3].setDim(3, y/2);
      
      for(blockPositions block : blocks)
      {
        g[block.getX()][block.getY()].setIcon(blockColor);
        g[block.getX()][block.getY()].setState("iTetrominoe");
      }  
      
      if(success)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    @Override
    public boolean moveDown()
    {
      if(vertical)
      {
        if(blocks[3].getX()+1 < g.length)
        {
          if(g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background"))
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("iTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if(blocks[3].getX()+1 < g.length)
        {
          if((g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background")) &&
             (g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
              
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("iTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveLeft()
    {
      if(vertical)
      {
        if(blocks[3].getY()-1 >= 0)
        {
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
              
              block.setY(block.getY()-1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("iTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if(blocks[2].getY()-1 >= 0)
        {
          if(g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background"))
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("iTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveRight()
    {
      if(vertical)
      {
        if(blocks[3].getY()+1 < g[0].length)
        {
          if((g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
              
              block.setY(block.getY()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("iTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if(blocks[0].getY()+1 < g[0].length)
        {
          if(g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background"))
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("iTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public void rotateClock()
    { 
      if(vertical)
      {
        boolean movedLeft = false;
        int amountMoved = 0;
        
        //check for grid border
        if(blocks[2].getY()+3 >= g[0].length)
        {
          int distanceFromBorder = (blocks[2].getY()+3) - (g[0].length-1);
          for(int i = 0; i < distanceFromBorder; ++i)
          {
            if(this.moveLeft())
            {
              ++amountMoved;
              movedLeft = true;
            }
          }
          
        }
        
        //check whether piece is far enough from border to rotate
        if(blocks[2].getY()+3 < g.length)
        {
          //check that adjacent blocks are not occupied by already played pieces
          if((g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+2].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+3].getState().equals("background"))    )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            blocks[0].setX(blocks[2].getX());
            blocks[0].setY(blocks[2].getY()+3);
            g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
            g[blocks[0].getX()][blocks[0].getY()].setState("iTetrominoe");
            blocks[1].setX(blocks[2].getX());
            blocks[1].setY(blocks[2].getY()+2);
            g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
            g[blocks[1].getX()][blocks[1].getY()].setState("iTetrominoe");
            blocks[3].setX(blocks[2].getX());
            blocks[3].setY(blocks[2].getY()+1);
            g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
            g[blocks[3].getX()][blocks[3].getY()].setState("iTetrominoe");
            
            vertical = !vertical;
          }
        } 
        //if piece was moved left to make room for rotation but still couldn't rotate, move it back
        else if(movedLeft)
        {
          for(int i = 0; i < amountMoved; ++i)
          {
            this.moveRight();
          }
        }
      }
      else
      {
        boolean movedBlock2 = false;
        
        //check if there is something under our center block, move it up one if there is
        if((blocks[3].getX()+1 >= g.length) || 
           !(g[blocks[3].getX()+1][blocks[3].getX()].getState().equals("background")))
        {
          if(g[blocks[3].getX()-1][blocks[3].getX()].getState().equals("background"))
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            blocks[3].setX(blocks[3].getX()-1);
            g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
            g[blocks[3].getX()][blocks[3].getY()].setState("iTetrominoe");
            
            movedBlock2 = true;
          }
        }
        //check that the spaces above the center block are free 
        if((g[blocks[3].getX()-1][blocks[3].getY()].getState().equals("background")) &&
           (g[blocks[3].getX()-2][blocks[3].getY()].getState().equals("background"))   )
        {
          g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
          g[blocks[0].getX()][blocks[0].getY()].setState("background");
          g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
          g[blocks[1].getX()][blocks[1].getY()].setState("background");
          g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
          g[blocks[2].getX()][blocks[2].getY()].setState("background");
          g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
          g[blocks[3].getX()][blocks[3].getY()].setState("background");
          
          blocks[0].setX(blocks[3].getX()-2);
          blocks[0].setY(blocks[3].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("iTetrominoe");
          blocks[1].setX(blocks[3].getX()-1);
          blocks[1].setY(blocks[3].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("iTetrominoe");
          blocks[2].setX(blocks[3].getX());
          blocks[2].setY(blocks[3].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("iTetrominoe");
          blocks[3].setX(blocks[3].getX()+1);
          blocks[3].setY(blocks[3].getY());
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("iTetrominoe");
          
          vertical = !vertical;
        }
        //if center block was moved up but no rotation was possible, set it back down
        else if(movedBlock2)
        {
          g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
          g[blocks[2].getX()][blocks[2].getY()].setState("background");
          
          blocks[2].setX(blocks[2].getX()+1);
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("iTetrominoe");
        }
      }      
    }
    
    @Override
    public void rotateCounter()
    {
      this.rotateClock();
    }
    
    @Override
    public void hardSkip()
    {
      while(this.moveDown())
      {
      }
    }
    
    @Override
    public void softSkip(boolean keepGoing)
    {
      while(keepGoing)
      {
        this.moveDown();
      }
    }
    
  }
  
  class oTetrominoe implements Tetrominoe 
  {
    Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
    private blockPositions blocks[];
    private Icon blockColor;
    private TetrisTile[][] g;
    
    public oTetrominoe(TetrisTile[][] G)
    {
      blocks = new blockPositions[4];
      for(int i = 0; i < 4; ++i)
      {
        blocks[i] = new blockPositions();
      }
      
      blockColor = new ImageIcon( "TetrisImages/TetrisWhite.gif" );
      this.g = G;
    }
    
    public Icon getIcon()
    {
      return blockColor;
    }
    
    @Override
    public boolean insert()
    {
      boolean success = true;
      int x = g.length;
      int y = g[0].length;
      //System.out.println("dimensions of array are: " + x + "x" + y);
      
      if(!(g[0][(y/2)-1].getState().equals("background")) ||
         !(g[0][y/2].getState().equals("background")) ||
         !(g[1][(y/2)-1].getState().equals("background")) ||
         !(g[1][y/2].getState().equals("background"))   )
      {
        success = false;
      }
      
      blocks[0].setDim(0, (y/2)-1);
      blocks[1].setDim(0, y/2);
      blocks[2].setDim(1, (y/2)-1);
      blocks[3].setDim(1, (y/2));
      
      for(blockPositions block : blocks)
      {
        g[block.getX()][block.getY()].setIcon(blockColor);
        g[block.getX()][block.getY()].setState("oTetrominoe");
      }  
      
      if(success)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    @Override
    public boolean moveDown()
    {
      //check for border of grid
      if(blocks[3].getX()+1 < g.length)
      {
        //check that blocks have nothing under them
        if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
           (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )   
        {
          g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
          g[blocks[0].getX()][blocks[0].getY()].setState("background");
          g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
          g[blocks[1].getX()][blocks[1].getY()].setState("background");
          
          for(blockPositions block : blocks)
          {
            block.setX(block.getX()+1);
            
            g[block.getX()][block.getY()].setIcon(blockColor);
            g[block.getX()][block.getY()].setState("oTetrominoe");
          }
          
          return true;
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveLeft()
    {
      //check for border of grid
      if(blocks[0].getY()-1 >= 0)
      {
        //check that blocks have nothing under them
        if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
           (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background"))   )   
        {
          g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
          g[blocks[1].getX()][blocks[1].getY()].setState("background");
          g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
          g[blocks[3].getX()][blocks[3].getY()].setState("background");
          
          for(blockPositions block : blocks)
          {
            block.setY(block.getY()-1);
            
            g[block.getX()][block.getY()].setIcon(blockColor);
            g[block.getX()][block.getY()].setState("oTetrominoe");
          }
          
          return true;
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveRight()
    {
      //check for border of grid
      if(blocks[1].getY()+1 < g[0].length)
      {
        //check that blocks have nothing under them
        if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
           (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )   
        {
          g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
          g[blocks[0].getX()][blocks[0].getY()].setState("background");
          g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
          g[blocks[2].getX()][blocks[2].getY()].setState("background");
          
          for(blockPositions block : blocks)
          {
            block.setY(block.getY()+1);
            
            g[block.getX()][block.getY()].setIcon(blockColor);
            g[block.getX()][block.getY()].setState("oTetrominoe");
          }
          
          return true;
        }
      }
      
      return false;
    }
    
    @Override
    public void rotateClock()
    { 
      
    }
    
    @Override
    public void rotateCounter()
    {
      this.rotateClock();
    }
    
    @Override
    public void hardSkip()
    {
      while(this.moveDown())
      {
      }
    }
    
    @Override
    public void softSkip(boolean keepGoing)
    {
      while(keepGoing)
      {
        this.moveDown();
      }
    }
    
  }
  
  class tTetrominoe implements Tetrominoe 
  {
    Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
    private blockPositions blocks[];
    private Icon blockColor;
    private TetrisTile[][] g;
    private String position;
    
    public tTetrominoe(TetrisTile[][] G)
    {
      blocks = new blockPositions[4];
      for(int i = 0; i < 4; ++i)
      {
        blocks[i] = new blockPositions();
      }
      
      blockColor = new ImageIcon( "TetrisImages/TetrisRed.gif" );
      this.g = G;
      position = "notT";
    }
    
    public Icon getIcon()
    {
      return blockColor;
    }
    
    @Override
    public boolean insert()
    {
      boolean success = true;
      int x = g.length;
      int y = g[0].length;
      //System.out.println("dimensions of array are: " + x + "x" + y);
      
      if(!(g[1][(y/2)-1].getState().equals("background")) ||
         !(g[1][y/2].getState().equals("background")) ||
         !(g[1][(y/2)+1].getState().equals("background")) ||
         !(g[0][y/2].getState().equals("background"))   )
      {
        success = false;
      }
      
      blocks[0].setDim(1, (y/2)-1);
      blocks[1].setDim(1, (y/2));
      blocks[2].setDim(1, (y/2)+1);
      blocks[3].setDim(0, (y/2));
      
      for(blockPositions block : blocks)
      {
        g[block.getX()][block.getY()].setIcon(blockColor);
        g[block.getX()][block.getY()].setState("tTetrominoe");
      }  
      
      if(success)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    @Override
    public boolean moveDown()
    {
      if(position.equals("notT"))
      {
        if((blocks[0].getX()+1 < g.length))
        {
          if((g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("clockT"))
      {
        if((blocks[2].getX()+1 < g.length))
        {
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("T"))
      {
        if((blocks[3].getX()+1 < g.length))
        {
          if((g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("counterT"))
      {
        if((blocks[2].getX()+1 < g.length))
        {
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveLeft()
    {
      if(position.equals("notT"))
      {
        if((blocks[0].getY()-1 >= 0))
        {
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("clockT"))
      {
        if((blocks[0].getY()-1 >= 0))
        {
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("T"))
      {
        if((blocks[0].getY()-1 >= 0))
        {
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("counterT"))
      {
        if((blocks[3].getY()-1 >= 0))
        {
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveRight()
    {
      if(position.equals("notT"))
      {
        if((blocks[2].getY()+1 < g[0].length))
        {
          if((g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("clockT"))
      {
        if((blocks[3].getY()+1 < g[0].length))
        {
          if((g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("T"))
      {
        if((blocks[2].getY()+1 < g[0].length))
        {
          if((g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("counterT"))
      {
        if((blocks[0].getY()+1 < g[0].length))
        {
          if((g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public void rotateClock()
    { 
      if(position.equals("notT"))
      {
        boolean movedUp = false;
        
        //check for grid border
        if(blocks[1].getX()+1 >= g.length ||
           !(g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) )
        {
          //check blocks above to make sure they're empty
          if((g[blocks[0].getX()-1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[3].getX()-1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()-1][blocks[2].getY()].getState().equals("background"))   )
          {
            
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
            }
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("tTetrominoe");
            }
            
            movedUp = true;
          } 
        }
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")))
        {
          g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
          g[blocks[0].getX()][blocks[0].getY()].setState("background");
          
          blocks[0].setX(blocks[1].getX()-1);
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("tTetrominoe");
          //blocks[1].setX(blocks[0].getX());
          //blocks[1].setY(blocks[0].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("tTetrominoe");
          blocks[2].setX(blocks[1].getX()+1);
          blocks[2].setY(blocks[1].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("tTetrominoe");
          blocks[3].setX(blocks[1].getX());
          blocks[3].setY(blocks[1].getY()+1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("tTetrominoe");
          
          position = "clockT";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedUp)
        {
          this.moveDown();
        }
      }
      else if(position.equals("clockT"))
      {
        boolean movedRight = false;
        
        //check for grid border
        if((blocks[1].getY()-1 < 0) ||
           !(g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")))
        {
          this.moveRight();
          movedRight = true;
        }
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")))
        {
          g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
          g[blocks[0].getX()][blocks[0].getY()].setState("background");
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY()-1);
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("tTetrominoe");
          //blocks[1].setX(blocks[0].getX());
          //blocks[1].setY(blocks[0].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("tTetrominoe");
          blocks[2].setX(blocks[1].getX());
          blocks[2].setY(blocks[1].getY()+1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("tTetrominoe");
          blocks[3].setX(blocks[1].getX()+1);
          blocks[3].setY(blocks[1].getY());
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("tTetrominoe");
          
          position = "T";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedRight)
        {
          this.moveLeft();
        }
      }  
      else if(position.equals("T"))
      {
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")))
        {
          g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
          g[blocks[2].getX()][blocks[2].getY()].setState("background");
          
          blocks[0].setX(blocks[1].getX()-1);
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("tTetrominoe");
          //blocks[1].setX(blocks[0].getX());
          //blocks[1].setY(blocks[0].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("tTetrominoe");
          blocks[2].setX(blocks[1].getX()+1);
          blocks[2].setY(blocks[1].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("tTetrominoe");
          blocks[3].setX(blocks[1].getX());
          blocks[3].setY(blocks[1].getY()-1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("tTetrominoe");
          
          position = "counterT";
        }
      }
      else if(position.equals("counterT"))
      {
        boolean movedLeft = false;
        
        //check for grid border
        if((blocks[1].getY()+1 >= g[0].length) ||
           !(g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")))
        {
          this.moveLeft();
          movedLeft = true;
        }
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")))
        {
          g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
          g[blocks[2].getX()][blocks[2].getY()].setState("background");
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY()-1);
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("tTetrominoe");
          //blocks[1].setX(blocks[0].getX());
          //blocks[1].setY(blocks[0].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("tTetrominoe");
          blocks[2].setX(blocks[1].getX());
          blocks[2].setY(blocks[1].getY()+1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("tTetrominoe");
          blocks[3].setX(blocks[1].getX()-1);
          blocks[3].setY(blocks[1].getY());
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("tTetrominoe");
          
          position = "notT";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedLeft)
        {
          this.moveRight();
        }
      } 
    }
    
    @Override
    public void rotateCounter()
    {
      this.rotateClock();
      this.rotateClock();
      this.rotateClock();
    }
    
    @Override
    public void hardSkip()
    {
      while(this.moveDown())
      {
      }
    }
    
    @Override
    public void softSkip(boolean keepGoing)
    {
      while(keepGoing)
      {
        this.moveDown();
      }
    }
    
  }
  
  class sTetrominoe implements Tetrominoe 
  {
    Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
    private blockPositions blocks[];
    private Icon blockColor;
    private TetrisTile[][] g;
    private boolean vertical;
    
    public sTetrominoe(TetrisTile[][] G)
    {
      blocks = new blockPositions[4];
      for(int i = 0; i < 4; ++i)
      {
        blocks[i] = new blockPositions();
      }
      
      blockColor = new ImageIcon( "TetrisImages/TetrisBlue.gif" );
      this.g = G;
      vertical = false;
    }
    
    public Icon getIcon()
    {
      return blockColor;
    }
    
    @Override
    public boolean insert()
    {
      boolean success = true;
      int x = g.length;
      int y = g[0].length;
      //System.out.println("dimensions of array are: " + x + "x" + y);
      
      if(!(g[0][y/2].getState().equals("background")) ||
         !(g[0][(y/2)+1].getState().equals("background")) ||
         !(g[1][y/2].getState().equals("background")) ||
         !(g[1][(y/2)-1].getState().equals("background"))   )
      {
        success = false;
      }
      
      blocks[0].setDim(0, y/2);
      blocks[1].setDim(0, (y/2)+1);
      blocks[3].setDim(1, y/2);
      blocks[2].setDim(1, (y/2)-1);
      
      for(blockPositions block : blocks)
      {
        g[block.getX()][block.getY()].setIcon(blockColor);
        g[block.getX()][block.getY()].setState("sTetrominoe");
      }  
      
      if(success)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    @Override
    public boolean moveDown()
    {
      if(vertical)
      {
        if((blocks[0].getX()+1 < g.length) && 
           (blocks[2].getX()+1 < g.length)   )
        {
          if((g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("sTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if((blocks[3].getX()+1 < g.length) &&
           (blocks[2].getX()+1 < g.length) &&
           (blocks[1].getX()+1 < g.length)   )
        {
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("sTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveLeft()
    {
      if(vertical)
      {
        if((blocks[0].getY()-1 >= 0) &&
           (blocks[1].getY()-1 >= 0)   )
        {
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
            }
            for(blockPositions block : blocks)
            { 
              block.setY(block.getY()-1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("sTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if(blocks[2].getY()-1 >= 0)
        {
          if((g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
             (g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("sTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveRight()
    {
      if(vertical)
      {
        if((blocks[3].getY()+1 < g[0].length) &&
           (blocks[2].getY()+1 < g[0].length))
        {
          if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
            }
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("sTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if(blocks[1].getY()+1 < g[0].length)
        {
          if((g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("sTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public void rotateClock()
    { 
      if(!vertical)
      {
        boolean movedUp = false;
        
        //check for grid border
        if(blocks[3].getX()+1 >= g.length ||
           !(g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background")) ||
           !(g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background"))   )
        {
          //check blocks above to make sure they're empty
          if((g[blocks[0].getX()-1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()-1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            blocks[0].setX(blocks[0].getX()-1);
            g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
            g[blocks[0].getX()][blocks[0].getY()].setState("sTetrominoe");
            blocks[1].setX(blocks[1].getX()-1);
            g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
            g[blocks[1].getX()][blocks[1].getY()].setState("sTetrominoe");
            blocks[2].setX(blocks[2].getX()-1);
            g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
            g[blocks[2].getX()][blocks[2].getY()].setState("sTetrominoe");
            blocks[3].setX(blocks[2].getX());
            g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
            g[blocks[3].getX()][blocks[3].getY()].setState("sTetrominoe");
            
            movedUp = true;
          } 
        }
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background")) &&
           (g[blocks[3].getX()+1][blocks[3].getY()+1].getState().equals("background")) )
        {
          g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
          g[blocks[0].getX()][blocks[0].getY()].setState("background");
          g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
          g[blocks[1].getX()][blocks[1].getY()].setState("background");
          g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
          g[blocks[2].getX()][blocks[2].getY()].setState("background");
          g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
          g[blocks[3].getX()][blocks[3].getY()].setState("background");
          
          blocks[0].setX(blocks[3].getX());
          blocks[0].setY(blocks[3].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("sTetrominoe");
          blocks[1].setX(blocks[0].getX()-1);
          blocks[1].setY(blocks[0].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("sTetrominoe");
          blocks[2].setX(blocks[0].getX()+1);
          blocks[2].setY(blocks[0].getY()+1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("sTetrominoe");
          blocks[3].setX(blocks[0].getX());
          blocks[3].setY(blocks[0].getY()+1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("sTetrominoe");
          
          vertical = !vertical;
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedUp)
        {
          this.moveDown();
        }
      }
      else
      {
        boolean movedRight = false;
        
        //check for border of grid
        if((blocks[0].getY()-1 < 0))
        {
          if(this.moveRight())
          {
            movedRight = true;
          }
        }
        
        //check that adjacent blocks are free for rotation
        if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
           (g[blocks[0].getX()-1][blocks[0].getY()+1].getState().equals("background"))   )
        {
          g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
          g[blocks[0].getX()][blocks[0].getY()].setState("background");
          g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
          g[blocks[1].getX()][blocks[1].getY()].setState("background");
          g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
          g[blocks[2].getX()][blocks[2].getY()].setState("background");
          g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
          g[blocks[3].getX()][blocks[3].getY()].setState("background");
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("sTetrominoe");
          blocks[1].setX(blocks[0].getX());
          blocks[1].setY(blocks[0].getY()+1);
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("sTetrominoe");
          blocks[2].setX(blocks[0].getX()+1);
          blocks[2].setY(blocks[0].getY()-1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("sTetrominoe");
          blocks[3].setX(blocks[0].getX()+1);
          blocks[3].setY(blocks[0].getY());
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("sTetrominoe");
          
          vertical = !vertical;
        }
        //if center block was moved up but no rotation was possible, set it back down
        else if(movedRight)
        {
          this.moveLeft();
        }
      }      
    }
    
    @Override
    public void rotateCounter()
    {
      this.rotateClock();
    }
    
    @Override
    public void hardSkip()
    {
      while(this.moveDown())
      {
      }
    }
    
    @Override
    public void softSkip(boolean keepGoing)
    {
      while(keepGoing)
      {
        this.moveDown();
      }
    }
    
  }
  
  class zTetrominoe implements Tetrominoe 
  {
    Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
    private blockPositions blocks[];
    private Icon blockColor;
    private TetrisTile[][] g;
    private boolean vertical;
    
    public zTetrominoe(TetrisTile[][] G)
    {
      blocks = new blockPositions[4];
      for(int i = 0; i < 4; ++i)
      {
        blocks[i] = new blockPositions();
      }
      
      blockColor = new ImageIcon( "TetrisImages/TetrisTeal.gif" );
      this.g = G;
      vertical = false;
    }
    
    public Icon getIcon()
    {
      return blockColor;
    }
    
    @Override
    public boolean insert()
    {
      boolean success = true;
      int x = g.length;
      int y = g[0].length;
      //System.out.println("dimensions of array are: " + x + "x" + y);
      
      if(!(g[0][(y/2)-1].getState().equals("background")) ||
         !(g[0][y/2].getState().equals("background")) ||
         !(g[1][y/2].getState().equals("background")) ||
         !(g[1][(y/2)+1].getState().equals("background"))   )
      {
        success = false;
      }
      
      blocks[0].setDim(0, (y/2)-1);
      blocks[1].setDim(0, (y/2));
      blocks[2].setDim(1, (y/2));
      blocks[3].setDim(1, (y/2)+1);
      
      for(blockPositions block : blocks)
      {
        g[block.getX()][block.getY()].setIcon(blockColor);
        g[block.getX()][block.getY()].setState("zTetrominoe");
      }  
      
      if(success)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    @Override
    public boolean moveDown()
    {
      if(vertical)
      {
        //check grid border
        if((blocks[3].getX()+1 < g.length) && 
           (blocks[2].getX()+1 < g.length)   )
        {
          //check for adjacent blocks
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("zTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if((blocks[3].getX()+1 < g.length) &&
           (blocks[2].getX()+1 < g.length)   )
        {
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("zTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveLeft()
    {
      if(vertical)
      {
        if((blocks[3].getY()-1 >= 0) &&
           (blocks[1].getY()-1 >= 0)   )
        {
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
            }
            for(blockPositions block : blocks)
            { 
              block.setY(block.getY()-1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("zTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if(blocks[0].getY()-1 >= 0)
        {
          if((g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
             (g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("zTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveRight()
    {
      if(vertical)
      {
        if((blocks[0].getY()+1 < g[0].length) &&
           (blocks[2].getY()+1 < g[0].length))
        {
          if((g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
            }
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("zTetrominoe");
            }
            
            return true;
          }
        }
      }
      else
      {
        if(blocks[3].getY()+1 < g[0].length)
        {
          if((g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("zTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public void rotateClock()
    { 
      if(!vertical)
      {
        boolean movedUp = false;
        
        //check for grid border
        if(blocks[2].getX()+1 >= g.length ||
           !(g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background")) ||
           !(g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background"))   )
        {
          //check blocks above to make sure they're empty
          if((g[blocks[0].getX()-1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[3].getX()-1][blocks[3].getY()].getState().equals("background"))   )
          {
            for(blockPositions block : blocks)
            {
              g[block.getX()][block.getY()].setIcon(tetrisBack);
              g[block.getX()][block.getY()].setState("background");
            }
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()-1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("zTetrominoe");
            }
            
            movedUp = true;
          } 
        }
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
           (g[blocks[2].getX()+1][blocks[2].getY()-1].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("zTetrominoe");
          blocks[1].setX(blocks[2].getX());
          blocks[1].setY(blocks[2].getY()-1);
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("zTetrominoe");
          //blocks[2].setX(blocks[0].getX());
          //blocks[2].setY(blocks[0].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("zTetrominoe");
          blocks[3].setX(blocks[1].getX()+1);
          blocks[3].setY(blocks[1].getY());
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("zTetrominoe");
          
          vertical = !vertical;
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedUp)
        {
          this.moveDown();
        }
      }
      else
      {
        boolean movedLeft = false;
        
        //check for border of grid
        if((blocks[2].getY()+1 >= g[0].length))
        {
          if(this.moveLeft())
          {
            movedLeft = true;
          }
        }
        
        //check that adjacent blocks are free for rotation
        if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
           (g[blocks[0].getX()+1][blocks[0].getY()+1].getState().equals("background"))   )
        {
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          //blocks[0].setX(blocks[0].getX());
          blocks[0].setY(blocks[0].getY()-1);
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("zTetrominoe");
          blocks[1].setX(blocks[0].getX());
          blocks[1].setY(blocks[0].getY()+1);
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("zTetrominoe");
          //blocks[2].setX(blocks[0].getX()+1);
          //blocks[2].setY(blocks[0].getY()-1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("zTetrominoe");
          blocks[3].setX(blocks[2].getX());
          blocks[3].setY(blocks[2].getY()+1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("zTetrominoe");
          
          vertical = !vertical;
        }
        //if center block was moved up but no rotation was possible, set it back down
        else if(movedLeft)
        {
          this.moveRight();
        }
      }      
    }
    
    @Override
    public void rotateCounter()
    {
      this.rotateClock();
    }
    
    @Override
    public void hardSkip()
    {
      while(this.moveDown())
      {
      }
    }
    
    @Override
    public void softSkip(boolean keepGoing)
    {
      while(keepGoing)
      {
        this.moveDown();
      }
    }
    
  }
  
  class LTetrominoe implements Tetrominoe 
  {
    Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
    private blockPositions blocks[];
    private Icon blockColor;
    private TetrisTile[][] g;
    private String position;
    
    public LTetrominoe(TetrisTile[][] G)
    {
      blocks = new blockPositions[4];
      for(int i = 0; i < 4; ++i)
      {
        blocks[i] = new blockPositions();
      }
      
      blockColor = new ImageIcon( "TetrisImages/TetrisGreen.gif" );
      this.g = G;
      position = "L";
    }
    
    public Icon getIcon()
    {
      return blockColor;
    }
    
    @Override
    public boolean insert()
    {
      boolean success = true;
      int x = g.length;
      int y = g[0].length;
      //System.out.println("dimensions of array are: " + x + "x" + y);
      
      if(!(g[0][y/2].getState().equals("background")) ||
         !(g[1][y/2].getState().equals("background")) ||
         !(g[2][y/2].getState().equals("background")) ||
         !(g[2][(y/2)+1].getState().equals("background"))   )
      {
        success = false;
      }
      
      blocks[0].setDim(0, (y/2));
      blocks[1].setDim(1, (y/2));
      blocks[2].setDim(2, (y/2));
      blocks[3].setDim(2, (y/2)+1);
      
      for(blockPositions block : blocks)
      {
        g[block.getX()][block.getY()].setIcon(blockColor);
        g[block.getX()][block.getY()].setState("LTetrominoe");
      }  
      
      if(success)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    @Override
    public boolean moveDown()
    {
      if(position.equals("L"))
      {
        //check grid border
        if((blocks[3].getX()+1 < g.length))
        {
          //check for adjacent blocks
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz1"))
      {
        if((blocks[3].getX()+1 < g.length))
        {
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("upL"))
      {
        if((blocks[2].getX()+1 < g.length))
        {
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz2"))
      {
        if((blocks[2].getX()+1 < g.length))
        {
          if((g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveLeft()
    {
      if(position.equals("L"))
      {
        //check grid border
        if((blocks[0].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz1"))
      {
        //check grid border
        if((blocks[0].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("upL"))
      {
        //check grid border
        if((blocks[3].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz2"))
      {
        //check grid border
        if((blocks[0].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveRight()
    {
      if(position.equals("L"))
      {
        //check grid border
        if((blocks[3].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz1"))
      {
        //check grid border
        if((blocks[2].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("upL"))
      {
        //check grid border
        if((blocks[0].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background"))   )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz2"))
      {
        //check grid border
        if((blocks[0].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public void rotateClock()
    { 
      if(position.equals("L"))
      {
        boolean movedLeft = false;
        
        //check for grid border
        if(blocks[3].getY()+1 >= g[0].length ||
           !(g[blocks[3].getX()-1][blocks[3].getY()+1].getState().equals("background"))   )
        {
          if(this.moveLeft())
          {
            movedLeft = true;
          }
        } 
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
           (g[blocks[1].getX()][blocks[1].getY()+2].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("LTetrominoe");
          blocks[1].setX(blocks[1].getX());
          blocks[1].setY(blocks[1].getY()+1);
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("LTetrominoe");
          blocks[2].setX(blocks[1].getX());
          blocks[2].setY(blocks[1].getY()+1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("LTetrominoe");
          blocks[3].setX(blocks[0].getX()+1);
          blocks[3].setY(blocks[0].getY());
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("LTetrominoe");
          
          position = "hrz1";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedLeft)
        {
          this.moveRight();
        }
      }
      else if(position.equals("hrz1"))
      {
        boolean movedUp = false;
        int amountMoved = 0;
        
        //check for grid border
        if((blocks[1].getX()+2 >= g.length) ||
           !(g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")))
        {
          //check for adjacent blocks
          if((g[blocks[2].getX()-1][blocks[2].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[0].getX()-1][blocks[0].getY()].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            movedUp = true;
            ++amountMoved;
          }
          
          if((blocks[1].getX()+2 >= g.length) ||
             !(g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")))
          {
            //check for adjacent blocks
            if((g[blocks[2].getX()-1][blocks[2].getY()].getState().equals("background")) &&
               (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
               (g[blocks[0].getX()-1][blocks[0].getY()].getState().equals("background"))   )
            {
              g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
              g[blocks[1].getX()][blocks[1].getY()].setState("background");
              g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
              g[blocks[3].getX()][blocks[3].getY()].setState("background");
              g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
              g[blocks[2].getX()][blocks[2].getY()].setState("background");
              
              for(blockPositions block : blocks)
              {
                block.setX(block.getX()-1);
                
                g[block.getX()][block.getY()].setIcon(blockColor);
                g[block.getX()][block.getY()].setState("LTetrominoe");
              }
              
              ++amountMoved;
            }
          } 
        } 
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
           (g[blocks[1].getX()-1][blocks[1].getY()-1].getState().equals("background")) &&
           (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX()-1);
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("LTetrominoe");
          //blocks[1].setX(blocks[1].getX());
          //blocks[1].setY(blocks[1].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("LTetrominoe");
          blocks[2].setX(blocks[1].getX()+1);
          blocks[2].setY(blocks[1].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("LTetrominoe");
          blocks[3].setX(blocks[0].getX());
          blocks[3].setY(blocks[0].getY()-1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("LTetrominoe");
          
          position = "upL";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedUp)
        {
          for(int i = 0; i < amountMoved; ++i)
          {
            this.moveDown();
          }
        }
        
        if(movedUp)
        {
          for(int i = 0; i < amountMoved; ++i)
          {
            this.moveDown();
          }
        }
      }
      else if(position.equals("upL"))
      {
        boolean movedLeft = false;
        boolean rotated = false;
        
        //check for grid border
        if((blocks[3].getY()+1 >= g[0].length) ||
           !(g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background")) ||
           !(g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background"))  )
        {
          this.moveLeft();
          movedLeft = true;
        } 
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
           (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
           (g[blocks[1].getX()-1][blocks[1].getY()+1].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY()-1);
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("LTetrominoe");
          //blocks[1].setX(blocks[1].getX());
          //blocks[1].setY(blocks[1].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("LTetrominoe");
          blocks[2].setX(blocks[1].getX());
          blocks[2].setY(blocks[1].getY()+1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("LTetrominoe");
          blocks[3].setX(blocks[1].getX()-1);
          blocks[3].setY(blocks[1].getY()+1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("LTetrominoe");
          
          rotated = true;
          
          position = "hrz2";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedLeft)
        {
          this.moveRight();
        }
        
        if(rotated && movedLeft)
        {
          this.moveDown();
        }
      }
      else if(position.equals("hrz2"))
      {
        boolean movedUp = false;
        boolean rotated = false;
        
        //check for grid borders
        if((blocks[1].getX()+1 >= g.length) ||
           !(g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) ||
           !(g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) ||
           !(g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
        {
          //check for adjacent blocks
          if((g[blocks[3].getX()-1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[0].getX()-1][blocks[0].getY()].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("LTetrominoe");
            }
            
            movedUp = true;
          }
        }
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
           (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
           (g[blocks[1].getX()+1][blocks[1].getY()+1].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX()-1);
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("LTetrominoe");
          //blocks[1].setX(blocks[1].getX());
          //blocks[1].setY(blocks[1].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("LTetrominoe");
          blocks[2].setX(blocks[1].getX()+1);
          blocks[2].setY(blocks[1].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("LTetrominoe");
          blocks[3].setX(blocks[1].getX()+1);
          blocks[3].setY(blocks[1].getY()+1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("LTetrominoe");
          
          rotated = true;
          
          position = "L";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedUp)
        {
          this.moveDown();
        }
        
        if(rotated && movedUp)
        {
          this.moveDown();
        }
      }
    }
    
    @Override
    public void rotateCounter()
    {
      this.rotateClock();
      this.rotateClock();
      this.rotateClock();
    }
    
    @Override
    public void hardSkip()
    {
      while(this.moveDown())
      {
      }
    }
    
    @Override
    public void softSkip(boolean keepGoing)
    {
      while(keepGoing)
      {
        this.moveDown();
      }
    }
    
  }
  
  class backLTetrominoe implements Tetrominoe 
  {
    Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
    private blockPositions blocks[];
    private Icon blockColor;
    private TetrisTile[][] g;
    private String position;
    
    public backLTetrominoe(TetrisTile[][] G)
    {
      blocks = new blockPositions[4];
      for(int i = 0; i < 4; ++i)
      {
        blocks[i] = new blockPositions();
      }
      
      blockColor = new ImageIcon( "TetrisImages/TetrisYellow.gif" );
      this.g = G;
      position = "L";
    }
    
    public Icon getIcon()
    {
      return blockColor;
    }
    
    @Override
    public boolean insert()
    {
      boolean success = true;
      int x = g.length;
      int y = g[0].length;
      //System.out.println("dimensions of array are: " + x + "x" + y);
      
      if(!(g[0][y/2].getState().equals("background")) ||
         !(g[1][y/2].getState().equals("background")) ||
         !(g[2][y/2].getState().equals("background")) ||
         !(g[2][(y/2)-1].getState().equals("background"))   )
      {
        success = false;
      }
      
      blocks[0].setDim(0, (y/2));
      blocks[1].setDim(1, (y/2));
      blocks[2].setDim(2, (y/2));
      blocks[3].setDim(2, (y/2)-1);
      
      for(blockPositions block : blocks)
      {
        g[block.getX()][block.getY()].setIcon(blockColor);
        g[block.getX()][block.getY()].setState("backLTetrominoe");
      }  
      
      if(success)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    @Override
    public boolean moveDown()
    {
      if(position.equals("L"))
      {
        //check grid border
        if((blocks[3].getX()+1 < g.length))
        {
          //check for adjacent blocks
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz1"))
      {
        if((blocks[1].getX()+1 < g.length))
        {
          if((g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("upL"))
      {
        if((blocks[2].getX()+1 < g.length))
        {
          if((g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background")) &&
             (g[blocks[2].getX()+1][blocks[2].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz2"))
      {
        if((blocks[3].getX()+1 < g.length))
        {
          if((g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[3].getX()+1][blocks[3].getY()].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            { 
              block.setX(block.getX()+1);
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveLeft()
    {
      if(position.equals("L"))
      {
        //check grid border
        if((blocks[3].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz1"))
      {
        //check grid border
        if((blocks[0].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("upL"))
      {
        //check grid border
        if((blocks[0].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()-1].getState().equals("background")) &&
             (g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background"))   )
          {
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz2"))
      {
        //check grid border
        if((blocks[0].getY()-1 >= 0))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()-1].getState().equals("background"))   )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public boolean moveRight()
    {
      if(position.equals("L"))
      {
        //check grid border
        if((blocks[1].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[0].getX()][blocks[0].getY()+1].getState().equals("background")) &&
             (g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz1"))
      {
        //check grid border
        if((blocks[2].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("upL"))
      {
        //check grid border
        if((blocks[3].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
             (g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      else if(position.equals("hrz2"))
      {
        //check grid border
        if((blocks[2].getY()+1 < g[0].length))
        {
          //check for adjacent blocks
          if((g[blocks[2].getX()][blocks[2].getY()+1].getState().equals("background")) &&
             (g[blocks[3].getX()][blocks[3].getY()+1].getState().equals("background"))   )
          {
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setY(block.getY()+1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            return true;
          }
        }
      }
      
      return false;
    }
    
    @Override
    public void rotateClock()
    { 
      if(position.equals("L"))
      {
        boolean movedRight = false;
        
        //check for grid border
        if(!(g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) ||
           !(g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background"))   )
        {
          if(this.moveRight())
          {
            movedRight = true;
          }
        } 
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
           (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
           (g[blocks[0].getX()][blocks[0].getY()-1].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY()-1);
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("backLTetrominoe");
          //blocks[1].setX(blocks[1].getX());
          //blocks[1].setY(blocks[1].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("backLTetrominoe");
          blocks[2].setX(blocks[1].getX());
          blocks[2].setY(blocks[1].getY()+1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("backLTetrominoe");
          blocks[3].setX(blocks[0].getX()-1);
          blocks[3].setY(blocks[0].getY());
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("backLTetrominoe");
          
          position = "hrz1";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedRight)
        {
          this.moveLeft();
        }
      }
      else if(position.equals("hrz1"))
      {
        boolean movedUp = false;
        //int amountMoved = 0;
        
        //check for grid border
        if((blocks[1].getX()+1 >= g.length) ||
           !(g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")))
        {
          //check for adjacent blocks
          if((g[blocks[2].getX()-1][blocks[2].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[3].getX()-1][blocks[3].getY()].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[2].getX()][blocks[2].getY()].setIcon(tetrisBack);
            g[blocks[2].getX()][blocks[2].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            movedUp = true;
            //++amountMoved;
          }
        } 
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
           (g[blocks[1].getX()-1][blocks[1].getY()+1].getState().equals("background")) &&
           (g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX()-1);
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("backLTetrominoe");
          //blocks[1].setX(blocks[1].getX());
          //blocks[1].setY(blocks[1].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("backLTetrominoe");
          blocks[2].setX(blocks[1].getX()+1);
          blocks[2].setY(blocks[1].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("backLTetrominoe");
          blocks[3].setX(blocks[0].getX());
          blocks[3].setY(blocks[0].getY()+1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("backLTetrominoe");
          
          position = "upL";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedUp)
        {
          //for(int i = 0; i < amountMoved; ++i)
          //{
          this.moveDown();
          //}
        }
        
        /*if(movedUp)
         {
         //for(int i = 0; i < amountMoved; ++i)
         //{
         this.moveDown();
         //}
         }*/
      }
      else if(position.equals("upL"))
      {
        boolean movedRight = false;
        boolean rotated = false;
        
        //check for grid border
        if((blocks[1].getY()-1 < 0) ||
           !(g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")))
        {
          this.moveRight();
          movedRight = true;
        } 
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()][blocks[1].getY()+1].getState().equals("background")) &&
           (g[blocks[1].getX()][blocks[1].getY()-1].getState().equals("background")) &&
           (g[blocks[1].getX()+1][blocks[1].getY()+1].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX());
          blocks[0].setY(blocks[1].getY()-1);
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("backLTetrominoe");
          //blocks[1].setX(blocks[1].getX());
          //blocks[1].setY(blocks[1].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("backLTetrominoe");
          blocks[2].setX(blocks[1].getX());
          blocks[2].setY(blocks[1].getY()+1);
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("backLTetrominoe");
          blocks[3].setX(blocks[1].getX()+1);
          blocks[3].setY(blocks[1].getY()+1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("backLTetrominoe");
          
          rotated = true;
          
          position = "hrz2";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedRight)
        {
          this.moveLeft();
        }
        
        if(rotated && movedRight)
        {
          this.moveLeft();
        }
      }
      else if(position.equals("hrz2"))
      {
        boolean movedUp = false;
        boolean rotated = false;
        
        //check for grid borders
        if(!(g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) ||
           !(g[blocks[0].getX()+1][blocks[0].getY()].getState().equals("background"))   )
        {
          //check for adjacent blocks
          if((g[blocks[2].getX()-1][blocks[2].getY()].getState().equals("background")) &&
             (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
             (g[blocks[0].getX()-1][blocks[0].getY()].getState().equals("background"))   )
          {
            g[blocks[1].getX()][blocks[1].getY()].setIcon(tetrisBack);
            g[blocks[1].getX()][blocks[1].getY()].setState("background");
            g[blocks[0].getX()][blocks[0].getY()].setIcon(tetrisBack);
            g[blocks[0].getX()][blocks[0].getY()].setState("background");
            g[blocks[3].getX()][blocks[3].getY()].setIcon(tetrisBack);
            g[blocks[3].getX()][blocks[3].getY()].setState("background");
            
            for(blockPositions block : blocks)
            {
              block.setX(block.getX()-1);
              
              g[block.getX()][block.getY()].setIcon(blockColor);
              g[block.getX()][block.getY()].setState("backLTetrominoe");
            }
            
            movedUp = true;
          }
        }
        
        //check that adjacent blocks are not occupied by already played pieces
        if((g[blocks[1].getX()+1][blocks[1].getY()].getState().equals("background")) &&
           (g[blocks[1].getX()-1][blocks[1].getY()].getState().equals("background")) &&
           (g[blocks[1].getX()+1][blocks[1].getY()-1].getState().equals("background")) )
        {
          
          for(blockPositions block : blocks)
          {
            g[block.getX()][block.getY()].setIcon(tetrisBack);
            g[block.getX()][block.getY()].setState("background");
          }
          
          
          blocks[0].setX(blocks[1].getX()-1);
          blocks[0].setY(blocks[1].getY());
          g[blocks[0].getX()][blocks[0].getY()].setIcon(blockColor);
          g[blocks[0].getX()][blocks[0].getY()].setState("backLTetrominoe");
          //blocks[1].setX(blocks[1].getX());
          //blocks[1].setY(blocks[1].getY());
          g[blocks[1].getX()][blocks[1].getY()].setIcon(blockColor);
          g[blocks[1].getX()][blocks[1].getY()].setState("backLTetrominoe");
          blocks[2].setX(blocks[1].getX()+1);
          blocks[2].setY(blocks[1].getY());
          g[blocks[2].getX()][blocks[2].getY()].setIcon(blockColor);
          g[blocks[2].getX()][blocks[2].getY()].setState("backLTetrominoe");
          blocks[3].setX(blocks[1].getX()+1);
          blocks[3].setY(blocks[1].getY()-1);
          g[blocks[3].getX()][blocks[3].getY()].setIcon(blockColor);
          g[blocks[3].getX()][blocks[3].getY()].setState("backLTetrominoe");
          
          rotated = true;
          
          position = "L";
        }
        //if piece was moved up to make room for rotation but still couldn't rotate, move it back down
        else if(movedUp)
        {
          this.moveDown();
        }
        
        if(rotated && movedUp)
        {
          this.moveDown();
        }
      }
    }
    
    @Override
    public void rotateCounter()
    {
      this.rotateClock();
      this.rotateClock();
      this.rotateClock();
    }
    
    @Override
    public void hardSkip()
    {
      while(this.moveDown())
      {
      }
    }
    
    @Override
    public void softSkip(boolean keepGoing)
    {
      while(keepGoing)
      {
        this.moveDown();
      }
    }
    
  }
}


