/**********************************************************************************************************************
  * CS342 Project 5 Tetris
  * Instructor: Patrick Troy
  * 
  * Authors: Yordan Machin 
  * 
  * This file contains Jpanel for the actual Tetris panel and all its logic.
  * 
  *********************************************************************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.io.*;

//The Tetris Game Board and all of its accompanying functions for running and playing the game
public class TetrisGrid extends JPanel 
{
  private static TetrisGrid game = new TetrisGrid();
  private static TetrisTile buttons[][];
  private Container container;
  private GridLayout grid;

  private int level;
  private int score;
  private int totalLines;
  private GameThread runningGame;
  public TetFactory.Tetrominoe curr;


  /***************************************Button Icons************************************/
  private Icon tetrisBack = new ImageIcon( "TetrisImages/TetrisBackground.gif" );
  /***************************************************************************************/
  
  /***********************************Game Grid Constructor********************************/
  public static TetrisGrid getInstance()
  {
    return game;
  }
  
  private TetrisGrid()
  {
    level = 1;
    score = 0;
    totalLines = 0;
    this.setBackground(Color.BLACK);
    this.setPreferredSize(new Dimension(200,400));
    grid = new GridLayout(20,10,0,0);
    this.setLayout(grid);
    
    buttons = new TetrisTile[20][10];
    
    for(int i = 0; i < 20; ++i)
    {
      for(int j = 0; j < 10; ++j)
      {   
        buttons[i][j] = new TetrisTile(i, j, "background", tetrisBack);
        buttons[i][j].setSize(16,16);
        buttons[i][j].setBorderPainted(false);
        //buttons[i][j].addMouseListener(mouse);
        this.add(buttons[i][j]);
      }
    }
      
  }
  
  //get game grid to feed to the GameThread as a parameter
  public TetrisTile[][] getGrid()
  {
    return this.buttons;
  }
  /***************************************************************************************/
  
  /***************************************Main For Debugging******************************/
  /*public static void main (String args[])
  {
    JFrame f = new JFrame();
    TetrisGrid game = new TetrisGrid();
    
    f.setLayout(new FlowLayout());
    Container container = f.getContentPane();
    container.add(game);
    
    f.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );     
    f.setPreferredSize(new Dimension(250,450));
    f.setMinimumSize(new Dimension(250,450));
    f.setVisible(true);
    f.pack();
    
    TetFactory factory = new TetFactory();
    int rand = (int )(Math.random() * 7);
    
    TetFactory.Tetrominoe tet = factory.getTet(rand, game.buttons);
    
    if(tet.insert())
    {
      System.out.println("success");
    }
    else
    {
      System.out.println("fail");
    }
    
    rand = (int )(Math.random() * 7);
    tet = factory.getTet(rand, game.buttons);
    
    if(tet.insert())
    {
      System.out.println("success");
    }
    else
    {
      System.out.println("fail");
    }
    
    //iTetrominoe first = new iTetrominoe(game.buttons);
    //first.insert();
    //first.hardSkip();
    
    //oTetrominoe first = new oTetrominoe(game.buttons);
    //first.insert();
    //first.hardSkip();
 
    //Tetrominoe first = new sTetrominoe(game.buttons);
    //first.insert();
    //first.hardSkip();
    //first.rotateClock();
    
    //Tetrominoe first = new zTetrominoe(game.buttons);
    //first.insert();
    //first.hardSkip();
    
    //Tetrominoe first = new LTetrominoe(game.buttons);
    //first.insert();
    //first.hardSkip();
    
    //Tetrominoe first = new backLTetrominoe(game.buttons);
    //first.insert();
    //first.hardSkip();
    
    //Tetrominoe first = new tTetrominoe(game.buttons);
    //first.insert();
    //first.hardSkip();
    
    
  }
  */
  /***************************************************************************************/
  
  //get games current score
  public int getScore()
  {
    return score;
  }
  
  //get games current level
  public int getLevel()
  {
    return level;
  }

  //reset the game grid and start a new game thread
  public void resetGrid()
  {
    runningGame.setRunning(false);
    level = 1;
    score = 0;
    totalLines = 0;
    
    for(int i = 0; i < 20; ++i)
    {
      for(int j = 0; j < 10; ++j)
      {   
        buttons[i][j].setIcon(tetrisBack);
        buttons[i][j].setState("background");
      }
    }
    
    runningGame = new GameThread(this);
    
  }
 /*******************row deletion*************************************/ 
  public void deleteR(int row){
    for(int i = row; i > 0 ; i--){
      for(int j = 0; j < 10 ; j++){
        buttons[i][j].setState(buttons[i-1][j].getState());
        buttons[i][j].setIcon(buttons[i-1][j].getIcon());
      }
    }
  }
  
  public void rowClear(){
    
    
    int count = 0;
    boolean full;
    for(int i = 19 ; i >= 0 ; i--){
      full = true;
      for(int j = 0; j < 10 ; j++){
        if(buttons[i][j].getState() == "background"){
          full = false;
          break;
        }
      }
      if(full){
        count++;
        totalLines++;
        if(totalLines%10 == 0){
          level++;
          runningGame.setDelay(level);
        }
        deleteR(i);
        i++;
      }
    }
    
    if(count == 1){
      score += 40;
    }
    else if(count == 2){
      score+= 100;
    }
    else if(count == 3){
      score+= 300;
    }
    else if(count == 4){
      score+= 1200;
    }
    
  }
  
   /*******************row deletion*************************************/ 
  
  //function to cause a delay in thread execution, used for delay on moving pieces down
  public void delay(int amount)
  {
    try {
      Thread.sleep(amount * 1000);                 //1000 milliseconds is one second.
    } catch(InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
  }
  
  //begin game thread execution
  public void startGame()
  {
    System.out.println("Beginning game.. Have Fun!!");
    runningGame = new GameThread(this);

    
  }
  
  //Thread that handles piece insertion and moving them down automatically
  class GameThread extends Thread
  {
    private TetrisTile[][] grid;
    private int delayAmount;
    private boolean running;
    
    public void setDelay(int level)
    {
      delayAmount = (50 - (level * 2))/25;
    }

    
    //used to avoid calling thread.stop
    public void setRunning(boolean state)
    {
      running = state;
    }
    
    public GameThread (TetrisGrid G) 
    {
     // setFocusable(true);
      grid = G.getGrid();
      delayAmount = (50 - (level * 2))/25;
      running = true;
    //  addKeyListener(new TAdapter(curr));
      start();
    }
    
    public void run()
    {
    //  setFocusable(true);
      TetFactory factory = new TetFactory();
      int rand = (int )(Math.random() * 7);
    
      TetFactory.Tetrominoe tet = factory.getTet(rand, grid); 
      

      //make sure its possible to insert a new piece
      while(tet.insert())
      {
        curr = tet;
         //addKeyListener(new TAdapter(curr));
        //addKeyListener(new TAdapter(tet));
        //need to wait a sec before moving piece down the for the first time 
        delay(delayAmount);
        
        //move piece down until it would otherwise collide with something
        while(tet.moveDown())
        {  
         // addKeyListener(new TAdapter(tet));
          //need to wait a sec before moving piece down each time
          delay(delayAmount);
          
          //make sure this particular thread is still running
          if(!running)
          {
            return;
          }

        }
        
        //check if any rows can be cleared
        rowClear();
        
        //spawn a new random tetris piece
        rand = (int )(Math.random() * 7);
        tet = factory.getTet(rand, grid);
      }
              
      
      //game over if no more pieces can  be inserted at the top center of the board
      System.out.println("game over...");
    }
  }
  
 
  
}
